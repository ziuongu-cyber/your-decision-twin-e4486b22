import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, ReferenceLine, ZAxis } from "recharts";
import { Target } from "lucide-react";
import { type Decision } from "@/lib/storage";

interface Props {
  decisions: Decision[];
}

export function ConfidenceVsOutcomeChart({ decisions }: Props) {
  const { chartData, trendLine } = useMemo(() => {
    const data: { confidence: number; outcome: number; title: string }[] = [];
    
    decisions.forEach(d => {
      const outcomes = d.outcomes || [];
      if (outcomes.length > 0) {
        const avgOutcome = outcomes.reduce((sum, o) => sum + o.rating, 0) / outcomes.length;
        data.push({
          confidence: d.confidence,
          outcome: Math.round(avgOutcome * 10) / 10,
          title: d.title,
        });
      }
    });

    // Calculate trend line (simple linear regression)
    let slope = 0;
    let intercept = 5;
    
    if (data.length >= 2) {
      const n = data.length;
      const sumX = data.reduce((sum, d) => sum + d.confidence, 0);
      const sumY = data.reduce((sum, d) => sum + d.outcome, 0);
      const sumXY = data.reduce((sum, d) => sum + d.confidence * d.outcome, 0);
      const sumX2 = data.reduce((sum, d) => sum + d.confidence * d.confidence, 0);
      
      slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
      intercept = (sumY - slope * sumX) / n;
    }
    
    return { 
      chartData: data,
      trendLine: { slope, intercept }
    };
  }, [decisions]);

  const chartConfig = {
    outcome: {
      label: "Outcome Rating",
      color: "hsl(var(--primary))",
    },
  };

  if (chartData.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Target className="h-4 w-4 text-primary" />
            Confidence vs Outcome
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[200px] flex items-center justify-center text-muted-foreground text-sm">
            Add outcomes to see correlation
          </div>
        </CardContent>
      </Card>
    );
  }

  // Calculate trend line endpoints
  const trendY1 = trendLine.slope * 0 + trendLine.intercept;
  const trendY2 = trendLine.slope * 100 + trendLine.intercept;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <Target className="h-4 w-4 text-primary" />
          Confidence vs Outcome
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[200px] w-full">
          <ScatterChart margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
            <XAxis 
              type="number"
              dataKey="confidence"
              domain={[0, 100]}
              tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
              tickLine={false}
              axisLine={false}
              label={{ value: 'Confidence %', position: 'bottom', fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
            />
            <YAxis 
              type="number"
              dataKey="outcome"
              domain={[0, 10]}
              tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
              tickLine={false}
              axisLine={false}
            />
            <ZAxis range={[60, 60]} />
            <ChartTooltip 
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="rounded-lg border bg-background p-2 shadow-sm">
                      <p className="font-medium text-sm">{data.title}</p>
                      <p className="text-xs text-muted-foreground">
                        Confidence: {data.confidence}% • Outcome: {data.outcome}/10
                      </p>
                    </div>
                  );
                }
                return null;
              }}
            />
            <ReferenceLine
              segment={[
                { x: 0, y: Math.max(0, Math.min(10, trendY1)) },
                { x: 100, y: Math.max(0, Math.min(10, trendY2)) }
              ]}
              stroke="hsl(var(--accent))"
              strokeDasharray="5 5"
              strokeWidth={2}
            />
            <Scatter 
              data={chartData} 
              fill="hsl(var(--primary))"
            />
          </ScatterChart>
        </ChartContainer>
        <p className="text-xs text-muted-foreground text-center mt-2">
          {trendLine.slope > 0.02 
            ? "📈 Higher confidence correlates with better outcomes"
            : trendLine.slope < -0.02
            ? "📉 Lower confidence sometimes leads to better outcomes"
            : "➡️ No strong correlation between confidence and outcome"
          }
        </p>
      </CardContent>
    </Card>
  );
}
