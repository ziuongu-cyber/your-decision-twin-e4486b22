import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Save } from "lucide-react";
import { DecisionTemplate, saveCustomTemplate } from "@/lib/templates";
import { useToast } from "@/hooks/use-toast";

const TEMPLATE_ICONS = ["📝", "💡", "🎯", "⭐", "🔮", "💭", "🧠", "📌"];

interface SaveTemplateModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  formData: {
    title: string;
    choice: string;
    alternatives: string;
    category: string;
    tags: string[];
    context: string;
  };
}

const SaveTemplateModal = ({ open, onOpenChange, formData }: SaveTemplateModalProps) => {
  const [name, setName] = useState("");
  const [icon, setIcon] = useState("📝");
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  const handleSave = async () => {
    if (!name.trim()) {
      toast({
        title: "Name required",
        description: "Please enter a name for your template.",
        variant: "destructive",
      });
      return;
    }

    setIsSaving(true);
    try {
      const template: DecisionTemplate = {
        id: `custom-${Date.now()}`,
        name: name.trim(),
        category: formData.category || "Other",
        tags: formData.tags,
        titlePlaceholder: formData.title || "What decision are you making?",
        choicePlaceholder: formData.choice || "What did you choose?",
        alternativesPlaceholder: formData.alternatives || "List alternatives",
        contextPlaceholder: formData.context || "Add context and thoughts",
        icon,
        isCustom: true,
      };

      await saveCustomTemplate(template);
      
      toast({
        title: "Template saved! 🎉",
        description: `"${name}" has been added to your templates.`,
      });
      
      setName("");
      setIcon("📝");
      onOpenChange(false);
    } catch (error) {
      console.error("Failed to save template:", error);
      toast({
        title: "Failed to save",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Save as Template</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="template-name">Template Name</Label>
            <Input
              id="template-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., My Career Template"
              className="bg-secondary"
            />
          </div>

          <div className="space-y-2">
            <Label>Icon</Label>
            <div className="flex flex-wrap gap-2">
              {TEMPLATE_ICONS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setIcon(emoji)}
                  className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl transition-all ${
                    icon === emoji
                      ? "bg-primary text-primary-foreground scale-110"
                      : "bg-secondary hover:bg-secondary/80"
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-muted/50 rounded-lg p-3 text-sm text-muted-foreground">
            <p className="font-medium mb-1">Template will include:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Category: {formData.category || "Other"}</li>
              <li>Tags: {formData.tags.length > 0 ? formData.tags.join(", ") : "None"}</li>
              <li>Pre-filled prompts and placeholders</li>
            </ul>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isSaving}>
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                Save Template
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default SaveTemplateModal;
