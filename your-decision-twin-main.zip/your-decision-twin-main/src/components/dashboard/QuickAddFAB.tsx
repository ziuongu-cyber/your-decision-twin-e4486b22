import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Plus, Zap } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

export function QuickAddFAB() {
  const navigate = useNavigate();
  const [isPressed, setIsPressed] = useState(false);

  const handleClick = () => {
    setIsPressed(true);
    // Add haptic feedback if available
    if (navigator.vibrate) {
      navigator.vibrate(50);
    }
    setTimeout(() => {
      navigate("/log-decision");
    }, 150);
  };

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          onClick={handleClick}
          onMouseDown={() => setIsPressed(true)}
          onMouseUp={() => setIsPressed(false)}
          onMouseLeave={() => setIsPressed(false)}
          className={cn(
            "fixed bottom-24 md:bottom-8 right-4 md:right-8 z-40",
            "w-14 h-14 rounded-full shadow-lg",
            "gradient-bg hover:scale-110 active:scale-95",
            "transition-all duration-200",
            "glow-primary",
            isPressed && "scale-95"
          )}
          size="icon"
          aria-label="Quick add decision"
        >
          <Plus className="w-6 h-6" />
        </Button>
      </TooltipTrigger>
      <TooltipContent side="left" className="flex items-center gap-2">
        <Zap className="w-4 h-4 text-primary" />
        Quick Add Decision
      </TooltipContent>
    </Tooltip>
  );
}
