import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, Cell, CartesianGrid } from "recharts";
import { BarChart3 } from "lucide-react";
import { type Decision } from "@/lib/storage";

interface Props {
  decisions: Decision[];
}

export function SuccessRateByCategoryChart({ decisions }: Props) {
  const chartData = useMemo(() => {
    const categoryData: Record<string, { total: number; count: number }> = {};
    
    decisions.forEach(d => {
      const outcomes = d.outcomes || [];
      if (outcomes.length > 0) {
        if (!categoryData[d.category]) {
          categoryData[d.category] = { total: 0, count: 0 };
        }
        outcomes.forEach(o => {
          categoryData[d.category].total += o.rating;
          categoryData[d.category].count += 1;
        });
      }
    });
    
    return Object.entries(categoryData)
      .map(([category, data]) => ({
        category: category.charAt(0).toUpperCase() + category.slice(1),
        rating: Math.round((data.total / data.count) * 10) / 10,
      }))
      .sort((a, b) => b.rating - a.rating);
  }, [decisions]);

  const getBarColor = (rating: number) => {
    if (rating < 4) return "hsl(0 84% 60%)"; // red
    if (rating <= 7) return "hsl(45 93% 47%)"; // yellow
    return "hsl(142 71% 45%)"; // green
  };

  const chartConfig = {
    rating: {
      label: "Avg Rating",
      color: "hsl(var(--primary))",
    },
  };

  if (chartData.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <BarChart3 className="h-4 w-4 text-primary" />
            Success Rate by Category
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[200px] flex items-center justify-center text-muted-foreground text-sm">
            Add outcomes to see category performance
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <BarChart3 className="h-4 w-4 text-primary" />
          Success Rate by Category
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[200px] w-full">
          <BarChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
            <XAxis 
              dataKey="category" 
              tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
              tickLine={false}
              axisLine={false}
            />
            <YAxis 
              domain={[0, 10]}
              tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
              tickLine={false}
              axisLine={false}
            />
            <ChartTooltip 
              content={<ChartTooltipContent />}
              cursor={{ fill: "hsl(var(--muted))", opacity: 0.3 }}
            />
            <Bar dataKey="rating" radius={[4, 4, 0, 0]}>
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={getBarColor(entry.rating)} />
              ))}
            </Bar>
          </BarChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
