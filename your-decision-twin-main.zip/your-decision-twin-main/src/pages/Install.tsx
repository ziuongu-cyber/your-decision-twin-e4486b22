import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  Download, 
  Smartphone, 
  Wifi, 
  Bell, 
  Sparkles,
  ArrowRight,
  Check,
  Share,
  PlusSquare,
} from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

const Install = () => {
  const navigate = useNavigate();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    // Check if already installed
    if (window.matchMedia("(display-mode: standalone)").matches) {
      setIsInstalled(true);
    }

    // Check if iOS
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent);
    setIsIOS(isIOSDevice);

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstall);

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstall);
    };
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;

    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;

    if (outcome === "accepted") {
      setIsInstalled(true);
    }
    setDeferredPrompt(null);
  };

  const features = [
    {
      icon: Smartphone,
      title: "Native App Experience",
      description: "Feels just like a native app on your device",
    },
    {
      icon: Wifi,
      title: "Works Offline",
      description: "Access your decisions even without internet",
    },
    {
      icon: Bell,
      title: "Push Notifications",
      description: "Get reminders to follow up on decisions",
    },
    {
      icon: Sparkles,
      title: "Quick Access",
      description: "Launch directly from your home screen",
    },
  ];

  return (
    <div className="min-h-screen mesh-gradient flex flex-col">
      <div className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="max-w-md w-full space-y-8">
          {/* Logo */}
          <div className="text-center">
            <div className="w-20 h-20 mx-auto rounded-2xl gradient-bg flex items-center justify-center mb-4 glow-primary">
              <Download className="w-10 h-10 text-primary-foreground" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Install Digital Twin</h1>
            <p className="text-muted-foreground">
              Add to your home screen for the best experience
            </p>
          </div>

          {/* Features */}
          <div className="glass-card rounded-2xl p-6 space-y-4">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <div key={idx} className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Install Button / Instructions */}
          {isInstalled ? (
            <div className="text-center space-y-4">
              <div className="flex items-center justify-center gap-2 text-green-400">
                <Check className="w-5 h-5" />
                <span>App is installed!</span>
              </div>
              <Button
                variant="hero"
                size="lg"
                className="w-full"
                onClick={() => navigate("/dashboard")}
              >
                Open App
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          ) : isIOS ? (
            <div className="glass-card rounded-2xl p-6 space-y-4">
              <h3 className="font-semibold text-center">Install on iOS</h3>
              <ol className="space-y-3 text-sm">
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-medium shrink-0">
                    1
                  </span>
                  <span className="flex items-center gap-2">
                    Tap the <Share className="w-4 h-4" /> Share button
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-medium shrink-0">
                    2
                  </span>
                  <span className="flex items-center gap-2">
                    Scroll and tap <PlusSquare className="w-4 h-4" /> Add to Home Screen
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-medium shrink-0">
                    3
                  </span>
                  <span>Tap Add to confirm</span>
                </li>
              </ol>
            </div>
          ) : deferredPrompt ? (
            <Button
              variant="hero"
              size="lg"
              className="w-full"
              onClick={handleInstall}
            >
              <Download className="w-5 h-5" />
              Install App
            </Button>
          ) : (
            <div className="text-center text-muted-foreground text-sm">
              <p>Installation not available on this browser.</p>
              <p className="mt-2">Try using Chrome, Edge, or Safari on mobile.</p>
            </div>
          )}

          {/* Skip link */}
          <div className="text-center">
            <button
              onClick={() => navigate("/dashboard")}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              Continue in browser →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Install;
