import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Decision, Outcome } from "@/lib/storage";
import { cn } from "@/lib/utils";

interface OutcomeModalProps {
  decision: Decision | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (decisionId: string, outcome: Outcome) => Promise<void>;
}

const OutcomeModal = ({ decision, isOpen, onClose, onSave }: OutcomeModalProps) => {
  const [rating, setRating] = useState(5);
  const [wouldChooseDifferently, setWouldChooseDifferently] = useState(false);
  const [reflection, setReflection] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const getRatingLabel = (value: number) => {
    if (value <= 3) return "Regret";
    if (value <= 6) return "Neutral";
    return "Great!";
  };

  const getRatingColor = (value: number) => {
    if (value < 4) return "text-red-400";
    if (value <= 7) return "text-yellow-400";
    return "text-green-400";
  };

  const handleSave = async () => {
    if (!decision) return;

    setIsSaving(true);
    try {
      const outcome: Outcome = {
        id: Date.now().toString(),
        rating,
        wouldChooseDifferently,
        reflection,
        createdAt: new Date().toISOString(),
      };
      await onSave(decision.id, outcome);
      handleClose();
    } finally {
      setIsSaving(false);
    }
  };

  const handleClose = () => {
    setRating(5);
    setWouldChooseDifferently(false);
    setReflection("");
    onClose();
  };

  if (!decision) return null;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md max-sm:h-[100dvh] max-sm:max-h-[100dvh] max-sm:rounded-none">
        <DialogHeader>
          <DialogTitle>Add Outcome</DialogTitle>
          <DialogDescription>
            Reflect on your decision: "{decision.title}"
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Rating slider */}
          <div className="space-y-4">
            <Label>How did this turn out?</Label>
            <div className="space-y-2">
              <Slider
                value={[rating]}
                onValueChange={(value) => setRating(value[0])}
                min={1}
                max={10}
                step={1}
                className="w-full"
              />
              <div className="flex justify-between items-center">
                <span className="text-xs text-muted-foreground">Regret</span>
                <span className={cn("text-lg font-semibold", getRatingColor(rating))}>
                  {rating}/10 - {getRatingLabel(rating)}
                </span>
                <span className="text-xs text-muted-foreground">Great</span>
              </div>
            </div>
          </div>

          {/* Would choose differently */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="choose-differently">Would you choose differently?</Label>
              <p className="text-xs text-muted-foreground">
                Looking back, would you make another choice?
              </p>
            </div>
            <Switch
              id="choose-differently"
              checked={wouldChooseDifferently}
              onCheckedChange={setWouldChooseDifferently}
            />
          </div>

          {/* Reflection notes */}
          <div className="space-y-2">
            <Label htmlFor="reflection">Reflection notes</Label>
            <Textarea
              id="reflection"
              placeholder="What did you learn? What would you do differently?"
              value={reflection}
              onChange={(e) => setReflection(e.target.value)}
              rows={4}
              className="resize-none"
            />
          </div>
        </div>

        <div className="flex gap-3 justify-end">
          <Button variant="outline" onClick={handleClose} disabled={isSaving}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isSaving}>
            {isSaving ? "Saving..." : "Save Outcome"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default OutcomeModal;
