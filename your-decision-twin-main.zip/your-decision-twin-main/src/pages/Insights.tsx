import { useState, useEffect, useRef, lazy, Suspense } from "react";
import DashboardLayout from "@/layouts/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { getAllDecisions, getInsights, saveInsights, type Decision, type Insights } from "@/lib/storage";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { 
  Brain, 
  Sparkles, 
  Target, 
  Lightbulb, 
  RefreshCw,
  ChevronRight,
  TrendingUp,
  Dna,
  Download
} from "lucide-react";
import { ErrorBoundary } from "@/components/common/ErrorBoundary";
import { InsightsSkeleton } from "@/components/common/DashboardSkeleton";
import { EmptyState } from "@/components/common/EmptyState";
import html2canvas from "html2canvas";

// Lazy load chart components for performance
const DecisionsOverTimeChart = lazy(() => 
  import("@/components/insights/DecisionsOverTimeChart").then(m => ({ default: m.DecisionsOverTimeChart }))
);
const SuccessRateByCategoryChart = lazy(() => 
  import("@/components/insights/SuccessRateByCategoryChart").then(m => ({ default: m.SuccessRateByCategoryChart }))
);
const ConfidenceVsOutcomeChart = lazy(() => 
  import("@/components/insights/ConfidenceVsOutcomeChart").then(m => ({ default: m.ConfidenceVsOutcomeChart }))
);
const DecisionBreakdownChart = lazy(() => 
  import("@/components/insights/DecisionBreakdownChart").then(m => ({ default: m.DecisionBreakdownChart }))
);

const CACHE_DURATION = 7 * 24 * 60 * 60 * 1000; // 7 days in milliseconds

export default function InsightsPage() {
  const [insights, setInsights] = useState<Insights | null>(null);
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [filteredDecisions, setFilteredDecisions] = useState<Decision[]>([]);
  const [loading, setLoading] = useState(true);
  const [regenerating, setRegenerating] = useState(false);
  const [selectedPattern, setSelectedPattern] = useState<{ pattern: string; examples: string[] } | null>(null);
  const [patternDecisions, setPatternDecisions] = useState<Decision[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const chartsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (selectedCategory) {
      setFilteredDecisions(decisions.filter(d => d.category.toLowerCase() === selectedCategory));
    } else {
      setFilteredDecisions(decisions);
    }
  }, [selectedCategory, decisions]);

  const loadData = async () => {
    const allDecisions = await getAllDecisions();
    setDecisions(allDecisions);
    setFilteredDecisions(allDecisions);

    // Check cache
    const cached = await getInsights();
    if (cached && Date.now() - cached.generatedAt < CACHE_DURATION) {
      setInsights(cached);
      setLoading(false);
      return;
    }

    // Generate new insights if no cache or expired
    if (allDecisions.length > 0) {
      await generateInsights(allDecisions);
    } else {
      setLoading(false);
    }
  };

  const generateInsights = async (decisionsToAnalyze: Decision[]) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("generate-insights", {
        body: { decisions: decisionsToAnalyze },
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);

      const newInsights: Insights = {
        ...data.insights,
        generatedAt: Date.now(),
      };

      await saveInsights(newInsights);
      setInsights(newInsights);
    } catch (error) {
      console.error("Failed to generate insights:", error);
      toast.error("Failed to generate insights. Please try again.");
    } finally {
      setLoading(false);
      setRegenerating(false);
    }
  };

  const handleRegenerate = async () => {
    if (decisions.length === 0) {
      toast.error("No decisions to analyze. Log some decisions first!");
      return;
    }
    setRegenerating(true);
    await generateInsights(decisions);
  };

  const handlePatternClick = (pattern: string, examples: string[]) => {
    const relatedDecisions = decisions.filter(d => examples.includes(d.id));
    setPatternDecisions(relatedDecisions);
    setSelectedPattern({ pattern, examples });
  };

  const handleCategoryClick = (category: string | null) => {
    setSelectedCategory(category);
    if (category) {
      toast.info(`Showing ${category} decisions`);
    } else {
      toast.info("Showing all decisions");
    }
  };

  const handleDownloadReport = async () => {
    if (!chartsRef.current) return;
    
    setExporting(true);
    try {
      const canvas = await html2canvas(chartsRef.current, {
        backgroundColor: "#0d0b14",
        scale: 2,
      });
      
      const link = document.createElement("a");
      link.download = `decision-insights-${new Date().toISOString().split("T")[0]}.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
      
      toast.success("Report downloaded!");
    } catch (error) {
      console.error("Failed to export:", error);
      toast.error("Failed to download report");
    } finally {
      setExporting(false);
    }
  };

  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case "high":
        return "bg-green-500/10 text-green-600 border-green-500/20";
      case "medium":
        return "bg-yellow-500/10 text-yellow-600 border-yellow-500/20";
      case "low":
        return "bg-muted text-muted-foreground";
      default:
        return "";
    }
  };

  // Chart loading skeleton
  const ChartSkeleton = () => (
    <Skeleton className="h-[280px] rounded-xl" />
  );

  if (loading && !insights) {
    return (
      <DashboardLayout>
        <InsightsSkeleton />
      </DashboardLayout>
    );
  }

  if (decisions.length === 0) {
    return (
      <DashboardLayout>
        <EmptyState
          icon={Brain}
          title="No Decisions Yet"
          description="Start logging decisions to unlock AI-powered insights about your decision-making patterns."
          action={
            <Button onClick={() => window.location.href = "/log-decision"}>
              Log Your First Decision
            </Button>
          }
          className="min-h-[60vh]"
        />
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Sparkles className="h-8 w-8 text-primary" />
              Decision Insights
            </h1>
            <p className="text-muted-foreground">
              AI-powered analysis of your decision-making patterns
            </p>
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={handleDownloadReport} 
              disabled={exporting}
              variant="outline"
              size="sm"
            >
              <Download className={`h-4 w-4 mr-2 ${exporting ? 'animate-pulse' : ''}`} />
              {exporting ? "Exporting..." : "Download Report"}
            </Button>
            <Button 
              onClick={handleRegenerate} 
              disabled={regenerating}
              variant="outline"
              size="sm"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${regenerating ? 'animate-spin' : ''}`} />
              {regenerating ? "Analyzing..." : "Regenerate"}
            </Button>
          </div>
        </div>

        {/* Charts Grid */}
        <ErrorBoundary>
          <div ref={chartsRef} className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Suspense fallback={<ChartSkeleton />}>
                <DecisionsOverTimeChart decisions={decisions} />
              </Suspense>
              <Suspense fallback={<ChartSkeleton />}>
                <SuccessRateByCategoryChart decisions={decisions} />
              </Suspense>
              <Suspense fallback={<ChartSkeleton />}>
                <ConfidenceVsOutcomeChart decisions={decisions} />
              </Suspense>
              <Suspense fallback={<ChartSkeleton />}>
                <DecisionBreakdownChart decisions={decisions} onCategoryClick={handleCategoryClick} />
              </Suspense>
            </div>

            {selectedCategory && (
            <Card className="border-accent/50">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">
                    Filtered: {selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} Decisions
                  </CardTitle>
                  <Button variant="ghost" size="sm" onClick={() => setSelectedCategory(null)}>
                    Clear filter
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2 sm:grid-cols-2">
                  {filteredDecisions.slice(0, 4).map(d => (
                    <div key={d.id} className="p-3 rounded-lg border bg-accent/10 text-sm">
                      <p className="font-medium truncate">{d.title}</p>
                      <p className="text-xs text-muted-foreground">{d.choice}</p>
                    </div>
                  ))}
                </div>
                {filteredDecisions.length > 4 && (
                  <p className="text-xs text-muted-foreground mt-2 text-center">
                    +{filteredDecisions.length - 4} more decisions
                  </p>
                )}
              </CardContent>
            </Card>
          )}
          </div>
        </ErrorBoundary>

        {insights && (
          <>
            {/* Decision DNA Card */}
            <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Dna className="h-5 w-5 text-primary" />
                  Your Decision DNA
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg leading-relaxed">{insights.personality}</p>
              </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-2">
              {/* Top Patterns */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-primary" />
                    Top Patterns Detected
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {insights.topPatterns.map((item, index) => (
                    <button
                      key={index}
                      onClick={() => handlePatternClick(item.pattern, item.examples)}
                      className="w-full text-left p-3 rounded-lg border hover:bg-accent/50 transition-colors flex items-center justify-between group"
                    >
                      <div className="flex items-center gap-3 flex-1">
                        <Badge className={getConfidenceColor(item.confidence)}>
                          {item.confidence}
                        </Badge>
                        <span className="text-sm">{item.pattern}</span>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                    </button>
                  ))}
                </CardContent>
              </Card>

              {/* Success Factors */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-green-500" />
                    What Makes Your Decisions Successful
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {insights.successFactors.map((factor, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <div className="h-6 w-6 rounded-full bg-green-500/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Target className="h-3 w-3 text-green-500" />
                        </div>
                        <span className="text-sm">{factor}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>

            {/* Recommendations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-yellow-500" />
                  Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 sm:grid-cols-2">
                  {insights.recommendations.map((rec, index) => (
                    <div
                      key={index}
                      className="p-4 rounded-lg bg-accent/30 border border-accent"
                    >
                      <div className="flex items-start gap-3">
                        <div className="h-6 w-6 rounded-full bg-yellow-500/10 flex items-center justify-center flex-shrink-0">
                          <span className="text-xs font-bold text-yellow-600">{index + 1}</span>
                        </div>
                        <p className="text-sm">{rec}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Cache info */}
            <p className="text-xs text-muted-foreground text-center">
              Insights generated {new Date(insights.generatedAt).toLocaleDateString()} • 
              Based on {decisions.length} decisions
            </p>
          </>
        )}
      </div>

      {/* Pattern Evidence Modal */}
      <Dialog open={!!selectedPattern} onOpenChange={() => setSelectedPattern(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Pattern Evidence</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">{selectedPattern?.pattern}</p>
            
            {patternDecisions.length > 0 ? (
              <div className="space-y-3">
                <p className="text-sm font-medium">Related Decisions:</p>
                {patternDecisions.map((decision) => (
                  <div
                    key={decision.id}
                    className="p-3 rounded-lg border bg-accent/20"
                  >
                    <p className="font-medium text-sm">{decision.title}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {decision.choice} • {new Date(decision.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                No specific decisions found for this pattern.
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
