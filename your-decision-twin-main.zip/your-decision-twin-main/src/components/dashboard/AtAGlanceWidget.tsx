import { useState, useEffect, useMemo } from "react";
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  ChevronDown, 
  ChevronUp,
  Target,
  Folder,
  Gauge,
  Bell,
  Calendar,
  CheckCircle,
  Flame,
  ArrowRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Decision, getPendingFollowups, Reminder } from "@/lib/storage";
import { cn } from "@/lib/utils";

interface AtAGlanceWidgetProps {
  decisions: Decision[];
  onReviewFollowups: () => void;
  onMetricClick?: (metric: string) => void;
}

// Mini sparkline component
const Sparkline = ({ data, color = "primary" }: { data: number[]; color?: string }) => {
  if (data.length < 2) return null;
  
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  
  const points = data.map((value, index) => {
    const x = (index / (data.length - 1)) * 60;
    const y = 20 - ((value - min) / range) * 16;
    return `${x},${y}`;
  }).join(" ");

  return (
    <svg width="60" height="24" className="opacity-60">
      <polyline
        fill="none"
        stroke={`hsl(var(--${color}))`}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={points}
      />
    </svg>
  );
};

// Animated counter component
const AnimatedNumber = ({ value, suffix = "" }: { value: number; suffix?: string }) => {
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    const duration = 1000;
    const steps = 30;
    const increment = value / steps;
    let current = 0;
    
    const timer = setInterval(() => {
      current += increment;
      if (current >= value) {
        setDisplayValue(value);
        clearInterval(timer);
      } else {
        setDisplayValue(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [value]);

  return (
    <span className="tabular-nums">
      {displayValue}{suffix}
    </span>
  );
};

// Trend indicator component
const TrendIndicator = ({ current, previous, suffix = "" }: { current: number; previous: number; suffix?: string }) => {
  const diff = current - previous;
  const isPositive = diff > 0;
  const isNeutral = diff === 0;

  if (isNeutral) {
    return (
      <span className="text-xs text-muted-foreground flex items-center gap-1">
        <Minus className="w-3 h-3" />
        Same as last week
      </span>
    );
  }

  return (
    <span className={cn(
      "text-xs flex items-center gap-1",
      isPositive ? "text-green-500" : "text-orange-500"
    )}>
      {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
      {isPositive ? "+" : ""}{diff}{suffix} vs last week
    </span>
  );
};

// Category icon map
const categoryIcons: Record<string, React.ReactNode> = {
  career: <Folder className="w-4 h-4" />,
  finance: <Folder className="w-4 h-4" />,
  health: <Folder className="w-4 h-4" />,
  relationships: <Folder className="w-4 h-4" />,
  personal: <Folder className="w-4 h-4" />,
  other: <Folder className="w-4 h-4" />,
};

export const AtAGlanceWidget = ({ decisions, onReviewFollowups, onMetricClick }: AtAGlanceWidgetProps) => {
  const [isOpen, setIsOpen] = useState(true);
  const [pendingCount, setPendingCount] = useState(0);

  // Load pending followups
  useEffect(() => {
    const loadPending = async () => {
      const pending = await getPendingFollowups();
      setPendingCount(pending.length);
    };
    loadPending();
  }, [decisions]);

  // Calculate all metrics
  const metrics = useMemo(() => {
    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay());
    startOfWeek.setHours(0, 0, 0, 0);
    
    const startOfLastWeek = new Date(startOfWeek);
    startOfLastWeek.setDate(startOfLastWeek.getDate() - 7);
    
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    // This week's decisions
    const thisWeekDecisions = decisions.filter(d => 
      new Date(d.createdAt) >= startOfWeek
    );
    
    // Last week's decisions
    const lastWeekDecisions = decisions.filter(d => {
      const date = new Date(d.createdAt);
      return date >= startOfLastWeek && date < startOfWeek;
    });
    
    // This month's decisions
    const thisMonthDecisions = decisions.filter(d => 
      new Date(d.createdAt) >= startOfMonth
    );

    // Most active category this week
    const categoryCount: Record<string, number> = {};
    thisWeekDecisions.forEach(d => {
      categoryCount[d.category] = (categoryCount[d.category] || 0) + 1;
    });
    const mostActiveCategory = Object.entries(categoryCount)
      .sort(([,a], [,b]) => b - a)[0]?.[0] || null;

    // Average confidence this week
    const thisWeekConfidence = thisWeekDecisions.length > 0
      ? Math.round(thisWeekDecisions.reduce((sum, d) => sum + d.confidence, 0) / thisWeekDecisions.length)
      : 0;
    const lastWeekConfidence = lastWeekDecisions.length > 0
      ? Math.round(lastWeekDecisions.reduce((sum, d) => sum + d.confidence, 0) / lastWeekDecisions.length)
      : 0;

    // Monthly success rate
    const monthlyOutcomes = thisMonthDecisions.flatMap(d => d.outcomes || []);
    const successRate = monthlyOutcomes.length > 0
      ? Math.round((monthlyOutcomes.reduce((sum, o) => sum + o.rating, 0) / monthlyOutcomes.length / 10) * 100)
      : 0;

    // Most improved category (compare this month vs all time)
    const categorySuccessThisMonth: Record<string, { total: number; count: number }> = {};
    const categorySuccessAllTime: Record<string, { total: number; count: number }> = {};
    
    thisMonthDecisions.forEach(d => {
      if (d.outcomes?.length) {
        if (!categorySuccessThisMonth[d.category]) {
          categorySuccessThisMonth[d.category] = { total: 0, count: 0 };
        }
        d.outcomes.forEach(o => {
          categorySuccessThisMonth[d.category].total += o.rating;
          categorySuccessThisMonth[d.category].count++;
        });
      }
    });
    
    decisions.forEach(d => {
      if (d.outcomes?.length) {
        if (!categorySuccessAllTime[d.category]) {
          categorySuccessAllTime[d.category] = { total: 0, count: 0 };
        }
        d.outcomes.forEach(o => {
          categorySuccessAllTime[d.category].total += o.rating;
          categorySuccessAllTime[d.category].count++;
        });
      }
    });

    let mostImprovedCategory: string | null = null;
    let maxImprovement = 0;
    Object.keys(categorySuccessThisMonth).forEach(cat => {
      const thisMonthAvg = categorySuccessThisMonth[cat].total / categorySuccessThisMonth[cat].count;
      const allTimeAvg = categorySuccessAllTime[cat]?.count 
        ? categorySuccessAllTime[cat].total / categorySuccessAllTime[cat].count 
        : thisMonthAvg;
      const improvement = thisMonthAvg - allTimeAvg;
      if (improvement > maxImprovement) {
        maxImprovement = improvement;
        mostImprovedCategory = cat;
      }
    });

    // Calculate streak (consecutive days with decisions)
    const sortedDates = [...new Set(decisions.map(d => 
      new Date(d.createdAt).toDateString()
    ))].sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
    
    let streak = 0;
    const today = new Date().toDateString();
    const yesterday = new Date(Date.now() - 86400000).toDateString();
    
    // Start counting from today or yesterday
    let checkDate = sortedDates[0] === today ? new Date() : 
      sortedDates[0] === yesterday ? new Date(Date.now() - 86400000) : null;
    
    if (checkDate) {
      for (const dateStr of sortedDates) {
        if (new Date(dateStr).toDateString() === checkDate.toDateString()) {
          streak++;
          checkDate.setDate(checkDate.getDate() - 1);
        } else {
          break;
        }
      }
    }

    // Sparkline data: decisions per day for last 7 days
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      date.setHours(0, 0, 0, 0);
      return date.toDateString();
    });
    const sparklineData = last7Days.map(dateStr => 
      decisions.filter(d => new Date(d.createdAt).toDateString() === dateStr).length
    );

    // Confidence sparkline
    const confidenceSparkline = last7Days.map(dateStr => {
      const dayDecisions = decisions.filter(d => new Date(d.createdAt).toDateString() === dateStr);
      return dayDecisions.length > 0 
        ? dayDecisions.reduce((sum, d) => sum + d.confidence, 0) / dayDecisions.length
        : 0;
    });

    return {
      thisWeekCount: thisWeekDecisions.length,
      lastWeekCount: lastWeekDecisions.length,
      mostActiveCategory,
      thisWeekConfidence,
      lastWeekConfidence,
      thisMonthCount: thisMonthDecisions.length,
      successRate,
      mostImprovedCategory,
      streak,
      sparklineData,
      confidenceSparkline,
    };
  }, [decisions]);

  if (decisions.length === 0) return null;

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <div className="glass-card rounded-2xl overflow-hidden">
        {/* Gradient header */}
        <div className="gradient-bg p-4 md:p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg md:text-xl font-bold text-white">At a Glance</h2>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="text-white/80 hover:text-white hover:bg-white/10">
                {isOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
              </Button>
            </CollapsibleTrigger>
          </div>
        </div>

        <CollapsibleContent>
          <div className="p-4 md:p-6 space-y-6">
            {/* This Week's Snapshot */}
            <div>
              <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wide">
                This Week's Snapshot
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {/* Decisions this week */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button 
                      onClick={() => onMetricClick?.("weekly-decisions")}
                      className="glass-card rounded-xl p-4 text-left hover:bg-secondary/50 transition-colors"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <Target className="w-4 h-4 text-primary" />
                        <Sparkline data={metrics.sparklineData} color="primary" />
                      </div>
                      <div className="text-2xl font-bold">
                        <AnimatedNumber value={metrics.thisWeekCount} />
                      </div>
                      <div className="text-xs text-muted-foreground mb-1">Decisions</div>
                      <TrendIndicator 
                        current={metrics.thisWeekCount} 
                        previous={metrics.lastWeekCount} 
                      />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Decisions logged this week</p>
                  </TooltipContent>
                </Tooltip>

                {/* Most active category */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button 
                      onClick={() => onMetricClick?.("category")}
                      className="glass-card rounded-xl p-4 text-left hover:bg-secondary/50 transition-colors"
                    >
                      <div className="flex items-center mb-2">
                        <Folder className="w-4 h-4 text-accent" />
                      </div>
                      <div className="text-lg font-bold truncate capitalize">
                        {metrics.mostActiveCategory || "—"}
                      </div>
                      <div className="text-xs text-muted-foreground">Most Active</div>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Your most active decision category this week</p>
                  </TooltipContent>
                </Tooltip>

                {/* Average confidence */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button 
                      onClick={() => onMetricClick?.("confidence")}
                      className="glass-card rounded-xl p-4 text-left hover:bg-secondary/50 transition-colors"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <Gauge className="w-4 h-4 text-accent" />
                        <Sparkline data={metrics.confidenceSparkline} color="accent" />
                      </div>
                      <div className="text-2xl font-bold">
                        <AnimatedNumber value={metrics.thisWeekConfidence} /><span className="text-muted-foreground text-base">/10</span>
                      </div>
                      <div className="text-xs text-muted-foreground mb-1">Avg Confidence</div>
                      <TrendIndicator 
                        current={metrics.thisWeekConfidence} 
                        previous={metrics.lastWeekConfidence} 
                      />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Average confidence level in your decisions</p>
                  </TooltipContent>
                </Tooltip>

                {/* Pending follow-ups */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button 
                      onClick={onReviewFollowups}
                      className="glass-card rounded-xl p-4 text-left hover:bg-secondary/50 transition-colors group"
                    >
                      <div className="flex items-center mb-2">
                        <Bell className={cn(
                          "w-4 h-4",
                          pendingCount > 0 ? "text-orange-500" : "text-muted-foreground"
                        )} />
                      </div>
                      <div className="text-2xl font-bold">
                        <AnimatedNumber value={pendingCount} />
                      </div>
                      <div className="text-xs text-muted-foreground mb-1">Pending</div>
                      {pendingCount > 0 && (
                        <span className="text-xs text-primary flex items-center gap-1 group-hover:underline">
                          Review <ArrowRight className="w-3 h-3" />
                        </span>
                      )}
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Decisions awaiting your outcome review</p>
                  </TooltipContent>
                </Tooltip>
              </div>
            </div>

            {/* This Month */}
            <div>
              <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wide">
                This Month
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {/* Total decisions */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button 
                      onClick={() => onMetricClick?.("monthly-total")}
                      className="glass-card rounded-xl p-4 text-left hover:bg-secondary/50 transition-colors"
                    >
                      <div className="flex items-center mb-2">
                        <Calendar className="w-4 h-4 text-primary" />
                      </div>
                      <div className="text-2xl font-bold">
                        <AnimatedNumber value={metrics.thisMonthCount} />
                      </div>
                      <div className="text-xs text-muted-foreground">Total Decisions</div>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Total decisions made this month</p>
                  </TooltipContent>
                </Tooltip>

                {/* Success rate */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button 
                      onClick={() => onMetricClick?.("success-rate")}
                      className="glass-card rounded-xl p-4 text-left hover:bg-secondary/50 transition-colors"
                    >
                      <div className="flex items-center mb-2">
                        <CheckCircle className={cn(
                          "w-4 h-4",
                          metrics.successRate >= 70 ? "text-green-500" : 
                          metrics.successRate >= 50 ? "text-yellow-500" : "text-muted-foreground"
                        )} />
                      </div>
                      <div className="text-2xl font-bold">
                        <AnimatedNumber value={metrics.successRate} suffix="%" />
                      </div>
                      <div className="text-xs text-muted-foreground">Success Rate</div>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Based on your outcome ratings this month</p>
                  </TooltipContent>
                </Tooltip>

                {/* Most improved */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button 
                      onClick={() => onMetricClick?.("improved-category")}
                      className="glass-card rounded-xl p-4 text-left hover:bg-secondary/50 transition-colors"
                    >
                      <div className="flex items-center mb-2">
                        <TrendingUp className="w-4 h-4 text-green-500" />
                      </div>
                      <div className="text-lg font-bold truncate capitalize">
                        {metrics.mostImprovedCategory || "—"}
                      </div>
                      <div className="text-xs text-muted-foreground">Most Improved</div>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Category with biggest improvement in outcomes</p>
                  </TooltipContent>
                </Tooltip>

                {/* Streak */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button 
                      onClick={() => onMetricClick?.("streak")}
                      className="glass-card rounded-xl p-4 text-left hover:bg-secondary/50 transition-colors"
                    >
                      <div className="flex items-center mb-2">
                        <Flame className={cn(
                          "w-4 h-4",
                          metrics.streak >= 7 ? "text-orange-500" : 
                          metrics.streak >= 3 ? "text-yellow-500" : "text-muted-foreground"
                        )} />
                      </div>
                      <div className="text-2xl font-bold">
                        <AnimatedNumber value={metrics.streak} />
                        <span className="text-base text-muted-foreground ml-1">days</span>
                      </div>
                      <div className="text-xs text-muted-foreground">Logging Streak</div>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Consecutive days of logging decisions</p>
                  </TooltipContent>
                </Tooltip>
              </div>
            </div>
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
};

export default AtAGlanceWidget;
