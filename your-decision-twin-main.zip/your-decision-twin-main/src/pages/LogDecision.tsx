import { useState, useEffect, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Save, X, Sparkles, Loader2, Edit, FileText, Bookmark } from "lucide-react";
import DashboardLayout from "@/layouts/DashboardLayout";
import {
  Decision,
  saveDecision,
  saveDraft,
  getDraft,
  clearDraft,
  createRemindersForDecision,
} from "@/lib/storage";
import { DecisionTemplate } from "@/lib/templates";
import TemplateModal from "@/components/templates/TemplateModal";
import SaveTemplateModal from "@/components/templates/SaveTemplateModal";

const CATEGORIES = [
  "Career",
  "Finance",
  "Health",
  "Relationships",
  "Purchase",
  "Daily Habit",
  "Other",
];

const CONFIDENCE_EMOJIS = ["😰", "😟", "😕", "🤔", "😐", "🙂", "😊", "😄", "😁", "🤩"];

interface DecisionForm {
  title: string;
  choice: string;
  alternatives: string;
  category: string;
  confidence: number;
  tags: string[];
  context: string;
}

const initialForm: DecisionForm = {
  title: "",
  choice: "",
  alternatives: "",
  category: "",
  confidence: 5,
  tags: [],
  context: "",
};

const LogDecision = () => {
  const [form, setForm] = useState<DecisionForm>(initialForm);
  const [tagInput, setTagInput] = useState("");
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [showSaveTemplateModal, setShowSaveTemplateModal] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  // Check if we're in edit mode
  const editingDecision = location.state?.editDecision as Decision | undefined;
  const templateFromNav = location.state?.template as DecisionTemplate | undefined;
  const isEditMode = !!editingDecision;

  // Load draft on mount or populate form for edit mode
  useEffect(() => {
    if (isEditMode && editingDecision) {
      // Populate form with existing decision data
      setForm({
        title: editingDecision.title || "",
        choice: editingDecision.choice || "",
        alternatives: editingDecision.alternatives?.join("\n") || "",
        category: editingDecision.category || "",
        confidence: editingDecision.confidence || 5,
        tags: editingDecision.tags || [],
        context: editingDecision.context || "",
      });
      // Clear the navigation state to prevent re-population on refresh
      window.history.replaceState({}, document.title);
    } else if (templateFromNav) {
      // Apply template from sidebar navigation
      setForm({
        title: "",
        choice: "",
        alternatives: templateFromNav.alternativesPlaceholder,
        category: templateFromNav.category,
        confidence: 5,
        tags: [...templateFromNav.tags],
        context: "",
      });
      toast({
        title: `Template applied: ${templateFromNav.name}`,
        description: "Form pre-filled with template. Customize as needed!",
      });
      // Clear navigation state
      window.history.replaceState({}, document.title);
    } else {
      // Load draft for new decision
      const loadDraft = async () => {
        try {
          const draft = await getDraft();
          if (draft) {
            setForm({
              title: draft.title || "",
              choice: draft.choice || "",
              alternatives: draft.alternatives?.join("\n") || "",
              category: draft.category || "",
              confidence: draft.confidence || 5,
              tags: draft.tags || [],
              context: draft.context || "",
            });
          }
        } catch (error) {
          console.error("Failed to load draft:", error);
        }
      };
      loadDraft();
    }
  }, [isEditMode, editingDecision, templateFromNav, toast]);

  // Auto-save draft every 30 seconds (only for new decisions)
  useEffect(() => {
    if (isEditMode) return; // Don't auto-save drafts when editing

    const interval = setInterval(async () => {
      if (form.title || form.choice) {
        try {
          await saveDraft({
            title: form.title,
            choice: form.choice,
            alternatives: form.alternatives.split("\n").filter(Boolean),
            category: form.category,
            confidence: form.confidence,
            tags: form.tags,
            context: form.context,
          });
          setLastSaved(new Date());
        } catch (error) {
          console.error("Failed to save draft:", error);
        }
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [form, isEditMode]);

  const updateField = useCallback(<K extends keyof DecisionForm>(
    field: K,
    value: DecisionForm[K]
  ) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  }, []);

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && tagInput.trim()) {
      e.preventDefault();
      const newTag = tagInput.trim().toLowerCase();
      if (!form.tags.includes(newTag)) {
        updateField("tags", [...form.tags, newTag]);
      }
      setTagInput("");
    }
  };

  const removeTag = (tagToRemove: string) => {
    updateField("tags", form.tags.filter((tag) => tag !== tagToRemove));
  };

  const handleSelectTemplate = (template: DecisionTemplate) => {
    setForm({
      title: "",
      choice: "",
      alternatives: template.alternativesPlaceholder,
      category: template.category,
      confidence: 5,
      tags: [...template.tags],
      context: "",
    });
    toast({
      title: `Template applied: ${template.name}`,
      description: "Form pre-filled with template. Customize as needed!",
    });
  };

  const handleSave = async () => {
    // Validation
    if (!form.title.trim()) {
      toast({
        title: "Missing information",
        description: "Please describe the decision you're making.",
        variant: "destructive",
      });
      return;
    }

    if (!form.choice.trim()) {
      toast({
        title: "Missing information",
        description: "Please enter what you chose.",
        variant: "destructive",
      });
      return;
    }

    setIsSaving(true);

    try {
      const decision: Decision = {
        id: isEditMode && editingDecision ? editingDecision.id : Date.now().toString(),
        title: form.title.trim(),
        choice: form.choice.trim(),
        alternatives: form.alternatives
          .split("\n")
          .map((alt) => alt.trim())
          .filter(Boolean),
        category: form.category || "Other",
        confidence: form.confidence,
        tags: form.tags,
        context: form.context.trim(),
        createdAt: isEditMode && editingDecision ? editingDecision.createdAt : new Date().toISOString(),
        outcomes: isEditMode && editingDecision ? editingDecision.outcomes : [],
      };

      // Save decision to storage
      await saveDecision(decision);

      // Create reminders for new decisions
      if (!isEditMode) {
        await createRemindersForDecision(decision);
        await clearDraft();
      }

      toast({
        title: isEditMode ? "Decision updated! ✨" : "Decision saved! ✨",
        description: isEditMode 
          ? "Your changes have been saved successfully."
          : "Your decision has been logged successfully.",
      });

      // Redirect to dashboard
      navigate("/dashboard", { state: { showSuccess: !isEditMode } });
    } catch (error) {
      console.error("Failed to save decision:", error);
      toast({
        title: "Failed to save",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className={`inline-flex p-3 rounded-2xl ${isEditMode ? 'bg-secondary' : 'gradient-bg'} mb-4`}>
            {isEditMode ? (
              <Edit className="w-6 h-6 text-foreground" />
            ) : (
              <Sparkles className="w-6 h-6 text-primary-foreground" />
            )}
          </div>
          <h1 className="text-2xl md:text-3xl font-bold mb-2">
            {isEditMode ? "Edit Decision" : "Log a Decision"}
          </h1>
          <p className="text-muted-foreground">
            {isEditMode 
              ? "Update the details of your decision"
              : "Take a moment to reflect on your choice"
            }
          </p>
          
          {/* Template buttons */}
          {!isEditMode && (
            <div className="flex justify-center gap-3 mt-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowTemplateModal(true)}
                className="gap-2"
              >
                <FileText className="w-4 h-4" />
                Use Template
              </Button>
              {(form.title || form.choice || form.category) && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowSaveTemplateModal(true)}
                  className="gap-2"
                >
                  <Bookmark className="w-4 h-4" />
                  Save as Template
                </Button>
              )}
            </div>
          )}
        </div>

        {/* Form */}
        <div className="space-y-6">
          {/* Decision Question */}
          <div className="glass-card rounded-xl p-6 transition-all duration-300 focus-within:ring-2 focus-within:ring-primary/50">
            <Label htmlFor="title" className="text-base font-medium mb-3 block">
              What decision are you making?
            </Label>
            <Input
              id="title"
              value={form.title}
              onChange={(e) => updateField("title", e.target.value)}
              placeholder="e.g., Should I take the new job offer?"
              className="text-lg bg-transparent border-0 border-b border-border/50 rounded-none px-0 focus-visible:ring-0 focus-visible:border-primary"
            />
          </div>

          {/* Choice Made */}
          <div className="glass-card rounded-xl p-6 transition-all duration-300 focus-within:ring-2 focus-within:ring-primary/50">
            <Label htmlFor="choice" className="text-base font-medium mb-3 block">
              What did you choose?
            </Label>
            <Input
              id="choice"
              value={form.choice}
              onChange={(e) => updateField("choice", e.target.value)}
              placeholder="e.g., I accepted the offer"
              className="bg-transparent border-0 border-b border-border/50 rounded-none px-0 focus-visible:ring-0 focus-visible:border-primary"
            />
          </div>

          {/* Alternatives */}
          <div className="glass-card rounded-xl p-6 transition-all duration-300 focus-within:ring-2 focus-within:ring-primary/50">
            <div className="flex justify-between items-center mb-3">
              <Label htmlFor="alternatives" className="text-base font-medium">
                Other options you considered
              </Label>
              <span className="text-xs text-muted-foreground">
                {form.alternatives.length}/500
              </span>
            </div>
            <Textarea
              id="alternatives"
              value={form.alternatives}
              onChange={(e) => updateField("alternatives", e.target.value.slice(0, 500))}
              placeholder="List alternatives, one per line"
              rows={3}
              className="bg-transparent border-0 border-b border-border/50 rounded-none px-0 resize-none focus-visible:ring-0 focus-visible:border-primary"
            />
          </div>

          {/* Category */}
          <div className="glass-card rounded-xl p-6 transition-all duration-300 focus-within:ring-2 focus-within:ring-primary/50">
            <Label className="text-base font-medium mb-3 block">Category</Label>
            <Select
              value={form.category}
              onValueChange={(value) => updateField("category", value)}
            >
              <SelectTrigger className="bg-secondary border-border/50">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent className="bg-popover border-border">
                {CATEGORIES.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Confidence Slider */}
          <div className="glass-card rounded-xl p-6">
            <div className="flex justify-between items-center mb-4">
              <Label className="text-base font-medium">
                How confident are you?
              </Label>
              <span className="text-3xl">{CONFIDENCE_EMOJIS[form.confidence - 1]}</span>
            </div>
            <div className="px-2">
              <Slider
                value={[form.confidence]}
                onValueChange={([value]) => updateField("confidence", value)}
                min={1}
                max={10}
                step={1}
                className="w-full"
              />
              <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                <span>Not confident</span>
                <span className="gradient-text font-medium">{form.confidence}/10</span>
                <span>Very confident</span>
              </div>
            </div>
          </div>

          {/* Tags */}
          <div className="glass-card rounded-xl p-6 transition-all duration-300 focus-within:ring-2 focus-within:ring-primary/50">
            <Label htmlFor="tags" className="text-base font-medium mb-3 block">
              Tags
            </Label>
            <div className="flex flex-wrap gap-2 mb-3">
              {form.tags.map((tag) => (
                <Badge
                  key={tag}
                  variant="secondary"
                  className="px-3 py-1 gap-1 hover:bg-destructive/20 cursor-pointer transition-colors"
                  onClick={() => removeTag(tag)}
                >
                  {tag}
                  <X className="w-3 h-3" />
                </Badge>
              ))}
            </div>
            <Input
              id="tags"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={handleAddTag}
              placeholder="Add tags like: important, urgent, financial (press Enter)"
              className="bg-transparent border-0 border-b border-border/50 rounded-none px-0 focus-visible:ring-0 focus-visible:border-primary"
            />
          </div>

          {/* Context */}
          <div className="glass-card rounded-xl p-6 transition-all duration-300 focus-within:ring-2 focus-within:ring-primary/50">
            <div className="flex justify-between items-center mb-3">
              <div>
                <Label htmlFor="context" className="text-base font-medium">
                  Context & Thoughts
                </Label>
                <span className="text-xs text-muted-foreground ml-2">(optional)</span>
              </div>
              <span className="text-xs text-muted-foreground">
                {form.context.length}/1000
              </span>
            </div>
            <Textarea
              id="context"
              value={form.context}
              onChange={(e) => updateField("context", e.target.value.slice(0, 1000))}
              placeholder="What were you thinking? How did you feel?"
              rows={4}
              className="bg-transparent border-0 border-b border-border/50 rounded-none px-0 resize-none focus-visible:ring-0 focus-visible:border-primary"
            />
          </div>

          {/* Save Button */}
          <div className="pt-4">
            <Button
              variant="hero"
              size="lg"
              className="w-full text-lg py-6"
              onClick={handleSave}
              disabled={isSaving}
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  {isEditMode ? "Updating..." : "Saving..."}
                </>
              ) : (
                <>
                  <Save className="w-5 h-5" />
                  {isEditMode ? "Update Decision" : "Save Decision"}
                </>
              )}
            </Button>
            {!isEditMode && lastSaved && (
              <p className="text-center text-xs text-muted-foreground mt-3">
                Draft auto-saved at {lastSaved.toLocaleTimeString()}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Modals */}
      <TemplateModal
        open={showTemplateModal}
        onOpenChange={setShowTemplateModal}
        onSelectTemplate={handleSelectTemplate}
      />
      <SaveTemplateModal
        open={showSaveTemplateModal}
        onOpenChange={setShowSaveTemplateModal}
        formData={form}
      />
    </DashboardLayout>
  );
};

export default LogDecision;
