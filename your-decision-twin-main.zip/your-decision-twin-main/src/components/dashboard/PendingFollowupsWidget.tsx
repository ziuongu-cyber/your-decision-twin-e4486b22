import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, ChevronRight, Clock } from "lucide-react";
import { getPendingFollowups, type Reminder, type Decision } from "@/lib/storage";
import { formatDistanceToNow, isPast } from "date-fns";
import { cn } from "@/lib/utils";

interface PendingFollowupsWidgetProps {
  onAddOutcome: (decisionId: string) => void;
}

export function PendingFollowupsWidget({ onAddOutcome }: PendingFollowupsWidgetProps) {
  const [pendingFollowups, setPendingFollowups] = useState<Array<Reminder & { decision?: Decision }>>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadPendingFollowups = async () => {
      try {
        const pending = await getPendingFollowups();
        setPendingFollowups(pending);
      } catch (error) {
        console.error("Failed to load pending followups:", error);
      } finally {
        setLoading(false);
      }
    };
    loadPendingFollowups();
  }, []);

  if (loading || pendingFollowups.length === 0) {
    return null;
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "1day": return "24h";
      case "7day": return "1 week";
      case "30day": return "1 month";
      default: return type;
    }
  };

  return (
    <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-base">
            <Bell className="w-5 h-5 text-primary" />
            Pending Follow-ups
          </span>
          <Badge variant="secondary" className="bg-primary/20 text-primary">
            {pendingFollowups.length}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {pendingFollowups.slice(0, 3).map((item) => {
          const isDue = isPast(new Date(item.dueDate));
          return (
            <button
              key={item.id}
              onClick={() => onAddOutcome(item.decisionId)}
              className="w-full text-left p-3 rounded-lg border bg-secondary/30 hover:bg-secondary/50 transition-colors group"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{item.decisionTitle}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge 
                      variant="outline" 
                      className={cn(
                        "text-xs",
                        isDue ? "border-primary/50 text-primary" : "text-muted-foreground"
                      )}
                    >
                      {getTypeLabel(item.type)} check-in
                    </Badge>
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {isDue 
                        ? "Due now" 
                        : `Due ${formatDistanceToNow(new Date(item.dueDate), { addSuffix: true })}`
                      }
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors shrink-0" />
              </div>
            </button>
          );
        })}
        {pendingFollowups.length > 3 && (
          <p className="text-xs text-center text-muted-foreground">
            +{pendingFollowups.length - 3} more pending
          </p>
        )}
      </CardContent>
    </Card>
  );
}
