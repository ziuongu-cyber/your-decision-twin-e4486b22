import { useState } from "react";
import { formatDistanceToNow, differenceInHours } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Decision, Outcome } from "@/lib/storage";
import {
  ChevronRight,
  Plus,
  Eye,
  Briefcase,
  DollarSign,
  Heart,
  Users,
  ShoppingCart,
  RefreshCw,
  HelpCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface DecisionCardProps {
  decision: Decision;
  onAddOutcome?: (decisionId: string) => void;
  onViewOutcome?: (decision: Decision) => void;
  onClick?: (decision: Decision) => void;
}

const CATEGORY_CONFIG: Record<
  string,
  { icon: React.ElementType; color: string; bgColor: string }
> = {
  Career: {
    icon: Briefcase,
    color: "text-blue-400",
    bgColor: "bg-blue-500/20",
  },
  Finance: {
    icon: DollarSign,
    color: "text-green-400",
    bgColor: "bg-green-500/20",
  },
  Health: {
    icon: Heart,
    color: "text-red-400",
    bgColor: "bg-red-500/20",
  },
  Relationships: {
    icon: Users,
    color: "text-pink-400",
    bgColor: "bg-pink-500/20",
  },
  Purchase: {
    icon: ShoppingCart,
    color: "text-yellow-400",
    bgColor: "bg-yellow-500/20",
  },
  "Daily Habit": {
    icon: RefreshCw,
    color: "text-cyan-400",
    bgColor: "bg-cyan-500/20",
  },
  Other: {
    icon: HelpCircle,
    color: "text-gray-400",
    bgColor: "bg-gray-500/20",
  },
};

const DecisionCard = ({ decision, onAddOutcome, onViewOutcome, onClick }: DecisionCardProps) => {
  const categoryConfig = CATEGORY_CONFIG[decision.category] || CATEGORY_CONFIG.Other;
  const CategoryIcon = categoryConfig.icon;

  const createdDate = new Date(decision.createdAt);
  const hoursSinceCreated = differenceInHours(new Date(), createdDate);
  const canAddOutcome = hoursSinceCreated >= 24;
  const hasOutcomes = decision.outcomes && decision.outcomes.length > 0;
  const latestOutcome = hasOutcomes ? decision.outcomes[decision.outcomes.length - 1] : null;

  // Confidence color gradient
  const getConfidenceColor = (confidence: number) => {
    if (confidence <= 3) return "bg-red-500";
    if (confidence <= 5) return "bg-yellow-500";
    if (confidence <= 7) return "bg-blue-500";
    return "bg-green-500";
  };

  // Outcome rating color
  const getOutcomeColor = (rating: number) => {
    if (rating < 4) return "text-red-400 bg-red-500/20";
    if (rating <= 7) return "text-yellow-400 bg-yellow-500/20";
    return "text-green-400 bg-green-500/20";
  };

  const handleCardClick = () => {
    onClick?.(decision);
  };

  return (
    <div
      className="glass-card rounded-xl overflow-hidden transition-all duration-200 hover:ring-1 hover:ring-primary/30 cursor-pointer group"
      onClick={handleCardClick}
    >
      {/* Main row */}
      <div className="w-full p-4 flex items-center gap-4 text-left">
        {/* Category icon */}
        <div
          className={cn(
            "w-10 h-10 rounded-lg flex items-center justify-center shrink-0",
            categoryConfig.bgColor
          )}
        >
          <CategoryIcon className={cn("w-5 h-5", categoryConfig.color)} />
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <h3 className="font-medium truncate">{decision.title}</h3>
          <p className="text-sm text-muted-foreground truncate">
            {decision.choice}
          </p>
        </div>

        {/* Right side info */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Outcome indicator */}
          {hasOutcomes && latestOutcome && (
            <span className={cn(
              "px-2 py-0.5 rounded text-xs font-medium hidden sm:block",
              getOutcomeColor(latestOutcome.rating)
            )}>
              {latestOutcome.rating}/10
            </span>
          )}

          {/* Confidence bar */}
          <div className="hidden sm:flex items-center gap-2">
            <div className="w-12 h-1.5 bg-secondary rounded-full overflow-hidden">
              <div
                className={cn(
                  "h-full rounded-full transition-all",
                  getConfidenceColor(decision.confidence)
                )}
                style={{ width: `${decision.confidence * 10}%` }}
              />
            </div>
          </div>

          {/* Category badge */}
          <Badge
            variant="secondary"
            className={cn("hidden md:flex text-xs", categoryConfig.bgColor, categoryConfig.color)}
          >
            {decision.category}
          </Badge>

          {/* Date */}
          <span className="text-xs text-muted-foreground whitespace-nowrap">
            {formatDistanceToNow(createdDate, { addSuffix: true })}
          </span>

          {/* Arrow icon */}
          <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
        </div>
      </div>
    </div>
  );
};

export default DecisionCard;
