import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer } from "@/components/ui/chart";
import { PieChart, Pie, Cell, Sector } from "recharts";
import { PieChart as PieChartIcon } from "lucide-react";
import { type Decision } from "@/lib/storage";

interface Props {
  decisions: Decision[];
  onCategoryClick?: (category: string | null) => void;
}

const COLORS = [
  "hsl(263 70% 58%)", // primary
  "hsl(220 80% 60%)", // accent
  "hsl(142 71% 45%)", // green
  "hsl(45 93% 47%)",  // yellow
  "hsl(0 84% 60%)",   // red
  "hsl(280 70% 55%)", // purple
  "hsl(180 70% 45%)", // teal
];

export function DecisionBreakdownChart({ decisions, onCategoryClick }: Props) {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const chartData = useMemo(() => {
    const categoryCount: Record<string, number> = {};
    
    decisions.forEach(d => {
      const cat = d.category || "other";
      categoryCount[cat] = (categoryCount[cat] || 0) + 1;
    });
    
    return Object.entries(categoryCount)
      .map(([name, value]) => ({
        name: name.charAt(0).toUpperCase() + name.slice(1),
        value,
        percentage: Math.round((value / decisions.length) * 100),
      }))
      .sort((a, b) => b.value - a.value);
  }, [decisions]);

  const chartConfig = chartData.reduce((acc, item, index) => {
    acc[item.name] = {
      label: item.name,
      color: COLORS[index % COLORS.length],
    };
    return acc;
  }, {} as Record<string, { label: string; color: string }>);

  const handleClick = (data: any, index: number) => {
    if (activeIndex === index) {
      setActiveIndex(null);
      onCategoryClick?.(null);
    } else {
      setActiveIndex(index);
      onCategoryClick?.(data.name.toLowerCase());
    }
  };

  const renderActiveShape = (props: any) => {
    const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload } = props;
    
    return (
      <g>
        <Sector
          cx={cx}
          cy={cy}
          innerRadius={innerRadius}
          outerRadius={outerRadius + 8}
          startAngle={startAngle}
          endAngle={endAngle}
          fill={fill}
          stroke="hsl(var(--background))"
          strokeWidth={2}
        />
        <text x={cx} y={cy - 8} textAnchor="middle" fill="hsl(var(--foreground))" fontSize={14} fontWeight="bold">
          {payload.name}
        </text>
        <text x={cx} y={cy + 12} textAnchor="middle" fill="hsl(var(--muted-foreground))" fontSize={12}>
          {payload.percentage}%
        </text>
      </g>
    );
  };

  if (chartData.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <PieChartIcon className="h-4 w-4 text-primary" />
            Decision Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[200px] flex items-center justify-center text-muted-foreground text-sm">
            No decisions to display
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <PieChartIcon className="h-4 w-4 text-primary" />
          Decision Breakdown
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[200px] w-full">
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={70}
              paddingAngle={2}
              dataKey="value"
              activeIndex={activeIndex ?? undefined}
              activeShape={renderActiveShape}
              onClick={handleClick}
              style={{ cursor: "pointer" }}
            >
              {chartData.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={COLORS[index % COLORS.length]}
                  stroke="hsl(var(--background))"
                  strokeWidth={1}
                />
              ))}
            </Pie>
          </PieChart>
        </ChartContainer>
        <div className="flex flex-wrap justify-center gap-3 mt-2">
          {chartData.map((entry, index) => (
            <button
              key={entry.name}
              onClick={() => handleClick(entry, index)}
              className={`flex items-center gap-1.5 text-xs transition-opacity ${
                activeIndex !== null && activeIndex !== index ? "opacity-50" : ""
              }`}
            >
              <span
                className="h-2.5 w-2.5 rounded-full"
                style={{ backgroundColor: COLORS[index % COLORS.length] }}
              />
              <span>{entry.name}</span>
              <span className="text-muted-foreground">({entry.value})</span>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
