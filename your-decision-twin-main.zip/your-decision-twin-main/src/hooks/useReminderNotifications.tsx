import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { X, Clock, Bell } from "lucide-react";
import { 
  getDueReminders, 
  updateReminderStatus, 
  type Reminder 
} from "@/lib/storage";

const LAST_CHECK_KEY = "reminder_last_check";
const CHECK_INTERVAL = 60 * 1000; // 1 minute

export function useReminderNotifications() {
  const [dueReminders, setDueReminders] = useState<Reminder[]>([]);
  const [shownReminders, setShownReminders] = useState<Set<string>>(new Set());
  const navigate = useNavigate();

  const checkReminders = useCallback(async () => {
    try {
      const due = await getDueReminders();
      setDueReminders(due);

      // Show toast for first unshown reminder
      const unshown = due.filter(r => !shownReminders.has(r.id));
      if (unshown.length > 0 && unshown[0]) {
        const reminder = unshown[0];
        showReminderToast(reminder);
        setShownReminders(prev => new Set([...prev, reminder.id]));
      }
    } catch (error) {
      console.error("Failed to check reminders:", error);
    }
  }, [shownReminders]);

  const showReminderToast = (reminder: Reminder) => {
    const typeLabel = reminder.type === "1day" ? "24 hours" 
      : reminder.type === "7day" ? "a week"
      : "a month";

    toast.custom((t) => (
      <div className="bg-card border border-border rounded-xl shadow-lg p-4 w-[360px] animate-slide-in-bottom">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center shrink-0">
            <Bell className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-medium text-sm mb-1">Time for a follow-up!</p>
            <p className="text-sm text-muted-foreground mb-3">
              It's been {typeLabel} since you made this decision:
            </p>
            <p className="text-sm font-medium truncate mb-3">
              "{reminder.decisionTitle}"
            </p>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="default"
                onClick={() => {
                  toast.dismiss(t);
                  navigate("/dashboard", { state: { openOutcome: reminder.decisionId } });
                }}
              >
                Add Outcome
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={async () => {
                  await updateReminderStatus(reminder.id, "snoozed", 1);
                  toast.dismiss(t);
                  toast.success("Reminder snoozed for 1 day");
                }}
              >
                <Clock className="w-3 h-3 mr-1" />
                Later
              </Button>
            </div>
          </div>
          <button
            onClick={() => toast.dismiss(t)}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    ), {
      duration: 15000,
      position: "top-right",
    });
  };

  useEffect(() => {
    // Initial check
    checkReminders();

    // Set up interval
    const interval = setInterval(checkReminders, CHECK_INTERVAL);

    return () => clearInterval(interval);
  }, [checkReminders]);

  return { dueReminders, checkReminders };
}
