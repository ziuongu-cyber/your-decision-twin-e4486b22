import { useState, useEffect } from "react";
import { Decision } from "@/lib/storage";
import {
  shareDecision,
  getSharesForDecision,
  revokeShare,
  getShareUrl,
  getSharingSettings,
  SharedDecision,
} from "@/lib/sharing";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import {
  Share2,
  Copy,
  Link,
  Clock,
  Eye,
  FileText,
  X,
  Check,
  MessageSquare,
  Trash2,
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";

interface ShareDecisionModalProps {
  decision: Decision | null;
  open: boolean;
  onClose: () => void;
}

const ShareDecisionModal = ({ decision, open, onClose }: ShareDecisionModalProps) => {
  const { toast } = useToast();
  const [shareType, setShareType] = useState<"full" | "summary">("summary");
  const [expireDays, setExpireDays] = useState(7);
  const [isSharing, setIsSharing] = useState(false);
  const [existingShares, setExistingShares] = useState<SharedDecision[]>([]);
  const [newShareUrl, setNewShareUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [sharingEnabled, setSharingEnabled] = useState(true);

  useEffect(() => {
    if (decision && open) {
      loadExistingShares();
      loadSettings();
    }
  }, [decision, open]);

  const loadSettings = async () => {
    const settings = await getSharingSettings();
    setSharingEnabled(settings.enabled);
    setShareType(settings.defaultShareType);
    setExpireDays(settings.defaultExpireDays);
  };

  const loadExistingShares = async () => {
    if (!decision) return;
    const shares = await getSharesForDecision(decision.id);
    const validShares = shares.filter(s => 
      !s.revoked && new Date(s.expiresAt) > new Date()
    );
    setExistingShares(validShares);
  };

  const handleCreateShare = async () => {
    if (!decision) return;
    
    setIsSharing(true);
    try {
      const shared = await shareDecision(decision, shareType, expireDays);
      const url = getShareUrl(shared.shareId);
      setNewShareUrl(url);
      await loadExistingShares();
      toast({
        title: "Share link created!",
        description: "Copy the link to share with your friend",
      });
    } catch (error) {
      toast({
        title: "Failed to create share",
        description: "Please try again",
        variant: "destructive",
      });
    } finally {
      setIsSharing(false);
    }
  };

  const handleCopyLink = async (url: string) => {
    await navigator.clipboard.writeText(url);
    setCopied(true);
    toast({
      title: "Link copied!",
      description: "Share link has been copied to clipboard",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRevokeShare = async (shareId: string) => {
    await revokeShare(shareId);
    await loadExistingShares();
    toast({
      title: "Access revoked",
      description: "This share link is no longer valid",
    });
  };

  if (!decision) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-primary" />
            Share Decision
          </DialogTitle>
          <DialogDescription>
            Share "{decision.title}" with a friend to get their advice
          </DialogDescription>
        </DialogHeader>

        <div className="overflow-y-auto flex-1 space-y-6 py-4">
          {/* New Share Form */}
          <div className="space-y-4">
            <div className="space-y-3">
              <Label>What to include</Label>
              <RadioGroup
                value={shareType}
                onValueChange={(v) => setShareType(v as "full" | "summary")}
                className="grid grid-cols-2 gap-3"
              >
                <Label
                  htmlFor="summary"
                  className={cn(
                    "flex flex-col items-center gap-2 p-4 rounded-lg border cursor-pointer transition-all",
                    shareType === "summary"
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50"
                  )}
                >
                  <RadioGroupItem value="summary" id="summary" className="sr-only" />
                  <FileText className="w-5 h-5 text-muted-foreground" />
                  <span className="font-medium">Summary Only</span>
                  <span className="text-xs text-muted-foreground text-center">
                    Basic info, no context
                  </span>
                </Label>
                <Label
                  htmlFor="full"
                  className={cn(
                    "flex flex-col items-center gap-2 p-4 rounded-lg border cursor-pointer transition-all",
                    shareType === "full"
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50"
                  )}
                >
                  <RadioGroupItem value="full" id="full" className="sr-only" />
                  <Eye className="w-5 h-5 text-muted-foreground" />
                  <span className="font-medium">Full Context</span>
                  <span className="text-xs text-muted-foreground text-center">
                    All details included
                  </span>
                </Label>
              </RadioGroup>
            </div>

            <div className="space-y-3">
              <Label className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Link expires in
              </Label>
              <div className="flex gap-2">
                {[1, 7, 14, 30].map((days) => (
                  <Button
                    key={days}
                    variant={expireDays === days ? "default" : "outline"}
                    size="sm"
                    onClick={() => setExpireDays(days)}
                  >
                    {days === 1 ? "1 day" : `${days} days`}
                  </Button>
                ))}
              </div>
            </div>

            <Button
              onClick={handleCreateShare}
              disabled={isSharing}
              className="w-full"
            >
              {isSharing ? (
                <>Creating link...</>
              ) : (
                <>
                  <Link className="w-4 h-4" />
                  Create Share Link
                </>
              )}
            </Button>

            {/* Newly created share URL */}
            {newShareUrl && (
              <div className="space-y-2 p-4 bg-primary/10 rounded-lg border border-primary/20">
                <Label className="text-sm font-medium text-primary">Share link created!</Label>
                <div className="flex gap-2">
                  <Input
                    value={newShareUrl}
                    readOnly
                    className="text-sm bg-background"
                  />
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => handleCopyLink(newShareUrl)}
                  >
                    {copied ? (
                      <Check className="w-4 h-4 text-green-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Existing Shares */}
          {existingShares.length > 0 && (
            <>
              <Separator />
              <div className="space-y-3">
                <Label className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                  Active Share Links
                </Label>
                <div className="space-y-2">
                  {existingShares.map((share) => (
                    <div
                      key={share.shareId}
                      className="flex items-center justify-between p-3 rounded-lg border bg-secondary/30"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {share.shareType === "full" ? "Full" : "Summary"}
                          </Badge>
                          {share.comments.length > 0 && (
                            <Badge variant="secondary" className="text-xs gap-1">
                              <MessageSquare className="w-3 h-3" />
                              {share.comments.length}
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          Expires {formatDistanceToNow(new Date(share.expiresAt), { addSuffix: true })}
                        </p>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleCopyLink(getShareUrl(share.shareId))}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="text-destructive hover:text-destructive"
                          onClick={() => handleRevokeShare(share.shareId)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ShareDecisionModal;
