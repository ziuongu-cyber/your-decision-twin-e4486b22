import { useState, useRef, TouchEvent } from "react";
import { cn } from "@/lib/utils";
import { Decision } from "@/lib/storage";
import { CheckCircle, Trash2 } from "lucide-react";
import DecisionCard from "@/components/dashboard/DecisionCard";
import { differenceInHours } from "date-fns";

interface SwipeableDecisionCardProps {
  decision: Decision;
  onAddOutcome?: (decisionId: string) => void;
  onViewOutcome?: (decision: Decision) => void;
  onClick?: (decision: Decision) => void;
  onDelete?: (decisionId: string) => void;
}

const SWIPE_THRESHOLD = 80;

const SwipeableDecisionCard = ({
  decision,
  onAddOutcome,
  onViewOutcome,
  onClick,
  onDelete,
}: SwipeableDecisionCardProps) => {
  const [swipeOffset, setSwipeOffset] = useState(0);
  const [isSwiping, setIsSwiping] = useState(false);
  const startXRef = useRef(0);
  const currentXRef = useRef(0);

  const hoursSinceCreated = differenceInHours(new Date(), new Date(decision.createdAt));
  const canAddOutcome = hoursSinceCreated >= 24;
  const hasOutcomes = decision.outcomes && decision.outcomes.length > 0;

  const handleTouchStart = (e: TouchEvent) => {
    startXRef.current = e.touches[0].clientX;
    currentXRef.current = e.touches[0].clientX;
    setIsSwiping(true);
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (!isSwiping) return;
    currentXRef.current = e.touches[0].clientX;
    const diff = currentXRef.current - startXRef.current;
    
    // Limit swipe range
    const limitedDiff = Math.max(-120, Math.min(120, diff));
    setSwipeOffset(limitedDiff);
  };

  const handleTouchEnd = () => {
    setIsSwiping(false);
    
    // Right swipe - add outcome
    if (swipeOffset > SWIPE_THRESHOLD && canAddOutcome && !hasOutcomes) {
      onAddOutcome?.(decision.id);
    }
    // Left swipe - delete
    else if (swipeOffset < -SWIPE_THRESHOLD) {
      onDelete?.(decision.id);
    }
    
    setSwipeOffset(0);
  };

  return (
    <div className="relative overflow-hidden rounded-xl md:overflow-visible">
      {/* Left action (delete) - appears when swiping left */}
      <div
        className={cn(
          "absolute inset-y-0 right-0 w-20 flex items-center justify-center bg-destructive transition-opacity md:hidden",
          swipeOffset < -30 ? "opacity-100" : "opacity-0"
        )}
      >
        <Trash2 className="w-6 h-6 text-destructive-foreground" />
      </div>

      {/* Right action (add outcome) - appears when swiping right */}
      <div
        className={cn(
          "absolute inset-y-0 left-0 w-20 flex items-center justify-center bg-green-500 transition-opacity md:hidden",
          swipeOffset > 30 && canAddOutcome && !hasOutcomes ? "opacity-100" : "opacity-0"
        )}
      >
        <CheckCircle className="w-6 h-6 text-white" />
      </div>

      {/* Card content */}
      <div
        className="relative bg-background transition-transform duration-200 ease-out md:transform-none"
        style={{ 
          transform: `translateX(${swipeOffset}px)`,
          transition: isSwiping ? 'none' : 'transform 200ms ease-out'
        }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <DecisionCard
          decision={decision}
          onClick={onClick}
          onAddOutcome={onAddOutcome}
          onViewOutcome={onViewOutcome}
        />
      </div>
    </div>
  );
};

export default SwipeableDecisionCard;
