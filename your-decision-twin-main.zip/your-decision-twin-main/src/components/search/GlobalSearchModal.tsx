import { useState, useEffect, useMemo, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Search,
  Clock,
  X,
  Briefcase,
  DollarSign,
  Heart,
  Users,
  ShoppingCart,
  RefreshCw,
  HelpCircle,
  FileText,
} from "lucide-react";
import { getAllDecisions, Decision } from "@/lib/storage";
import { formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";

const CATEGORY_CONFIG: Record<
  string,
  { icon: React.ElementType; color: string; bgColor: string }
> = {
  Career: { icon: Briefcase, color: "text-blue-400", bgColor: "bg-blue-500/20" },
  Finance: { icon: DollarSign, color: "text-green-400", bgColor: "bg-green-500/20" },
  Health: { icon: Heart, color: "text-red-400", bgColor: "bg-red-500/20" },
  Relationships: { icon: Users, color: "text-pink-400", bgColor: "bg-pink-500/20" },
  Purchase: { icon: ShoppingCart, color: "text-yellow-400", bgColor: "bg-yellow-500/20" },
  "Daily Habit": { icon: RefreshCw, color: "text-cyan-400", bgColor: "bg-cyan-500/20" },
  Other: { icon: HelpCircle, color: "text-gray-400", bgColor: "bg-gray-500/20" },
};

const RECENT_SEARCHES_KEY = "recent_searches";
const MAX_RECENT_SEARCHES = 5;

interface SearchResult extends Decision {
  matchedField: string;
  matchedText: string;
}

interface GlobalSearchModalProps {
  open: boolean;
  onClose: () => void;
}

const GlobalSearchModal = ({ open, onClose }: GlobalSearchModalProps) => {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Load decisions and recent searches
  useEffect(() => {
    if (open) {
      setIsLoading(true);
      getAllDecisions().then((data) => {
        setDecisions(data);
        setIsLoading(false);
      });

      // Load recent searches
      const saved = localStorage.getItem(RECENT_SEARCHES_KEY);
      if (saved) {
        try {
          setRecentSearches(JSON.parse(saved));
        } catch {
          setRecentSearches([]);
        }
      }
    }
  }, [open]);

  // Clear query when closing
  useEffect(() => {
    if (!open) {
      setQuery("");
    }
  }, [open]);

  // Highlight matching text
  const highlightMatch = useCallback((text: string, search: string) => {
    if (!search.trim()) return text;
    const regex = new RegExp(`(${search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    const parts = text.split(regex);
    
    return parts.map((part, i) => 
      regex.test(part) ? (
        <mark key={i} className="bg-primary/30 text-foreground rounded px-0.5">
          {part}
        </mark>
      ) : (
        part
      )
    );
  }, []);

  // Search and group results
  const { results, groupedResults } = useMemo(() => {
    if (!query.trim()) {
      return { results: [], groupedResults: {} as Record<string, SearchResult[]> };
    }

    const searchQuery = query.toLowerCase();
    const searchResults: SearchResult[] = [];

    decisions.forEach((decision) => {
      // Search in title
      if (decision.title.toLowerCase().includes(searchQuery)) {
        searchResults.push({
          ...decision,
          matchedField: "Title",
          matchedText: decision.title,
        });
        return;
      }

      // Search in choice
      if (decision.choice.toLowerCase().includes(searchQuery)) {
        searchResults.push({
          ...decision,
          matchedField: "Choice",
          matchedText: decision.choice,
        });
        return;
      }

      // Search in alternatives
      const matchedAlt = decision.alternatives.find((alt) =>
        alt.toLowerCase().includes(searchQuery)
      );
      if (matchedAlt) {
        searchResults.push({
          ...decision,
          matchedField: "Alternative",
          matchedText: matchedAlt,
        });
        return;
      }

      // Search in context
      if (decision.context.toLowerCase().includes(searchQuery)) {
        searchResults.push({
          ...decision,
          matchedField: "Context",
          matchedText: decision.context.slice(0, 100) + (decision.context.length > 100 ? "..." : ""),
        });
        return;
      }

      // Search in tags
      const matchedTag = decision.tags.find((tag) =>
        tag.toLowerCase().includes(searchQuery)
      );
      if (matchedTag) {
        searchResults.push({
          ...decision,
          matchedField: "Tag",
          matchedText: matchedTag,
        });
      }
    });

    // Group by category
    const grouped = searchResults.reduce((acc, result) => {
      const category = result.category;
      if (!acc[category]) {
        acc[category] = [];
      }
      acc[category].push(result);
      return acc;
    }, {} as Record<string, SearchResult[]>);

    return { results: searchResults, groupedResults: grouped };
  }, [query, decisions]);

  const handleSelectResult = (decision: Decision) => {
    // Save to recent searches
    const newRecent = [query, ...recentSearches.filter((s) => s !== query)].slice(
      0,
      MAX_RECENT_SEARCHES
    );
    setRecentSearches(newRecent);
    localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(newRecent));

    onClose();
    navigate("/history", { state: { openDecision: decision } });
  };

  const handleRecentSearch = (search: string) => {
    setQuery(search);
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem(RECENT_SEARCHES_KEY);
  };

  const removeRecentSearch = (search: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const filtered = recentSearches.filter((s) => s !== search);
    setRecentSearches(filtered);
    localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(filtered));
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="max-w-2xl p-0 gap-0 overflow-hidden sm:max-w-2xl sm:rounded-lg max-sm:h-[100dvh] max-sm:max-h-[100dvh] max-sm:rounded-none">
        <DialogHeader className="p-3 sm:p-4 pb-0">
          <DialogTitle className="sr-only">Search Decisions</DialogTitle>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search decisions by title, choice, tags, context..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-10 pr-10 h-12 text-base bg-secondary border-border/50"
              autoFocus
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh]">
          <div className="p-4">
            {isLoading ? (
              <div className="text-center py-8 text-muted-foreground">
                Loading...
              </div>
            ) : query.trim() ? (
              results.length > 0 ? (
                <div className="space-y-6">
                  {Object.entries(groupedResults).map(([category, categoryResults]) => {
                    const config = CATEGORY_CONFIG[category] || CATEGORY_CONFIG.Other;
                    const CategoryIcon = config.icon;

                    return (
                      <div key={category}>
                        <div className="flex items-center gap-2 mb-3">
                          <div
                            className={cn(
                              "w-6 h-6 rounded flex items-center justify-center",
                              config.bgColor
                            )}
                          >
                            <CategoryIcon className={cn("w-3.5 h-3.5", config.color)} />
                          </div>
                          <span className="text-sm font-medium text-muted-foreground">
                            {category}
                          </span>
                          <Badge variant="secondary" className="text-xs">
                            {categoryResults.length}
                          </Badge>
                        </div>
                        <div className="space-y-2">
                          {categoryResults.map((result) => (
                            <button
                              key={result.id}
                              onClick={() => handleSelectResult(result)}
                              className="w-full p-3 rounded-lg bg-secondary/50 hover:bg-secondary text-left transition-colors group"
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex-1 min-w-0">
                                  <h4 className="font-medium group-hover:text-primary transition-colors">
                                    {highlightMatch(result.title, query)}
                                  </h4>
                                  <p className="text-sm text-muted-foreground mt-1 truncate">
                                    <span className="text-xs text-primary/70 mr-1">
                                      {result.matchedField}:
                                    </span>
                                    {highlightMatch(result.matchedText, query)}
                                  </p>
                                </div>
                                <span className="text-xs text-muted-foreground whitespace-nowrap">
                                  {formatDistanceToNow(new Date(result.createdAt), {
                                    addSuffix: true,
                                  })}
                                </span>
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center mx-auto mb-4">
                    <FileText className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <h3 className="font-medium mb-2">No results found</h3>
                  <p className="text-sm text-muted-foreground">
                    Try using different keywords or check your spelling
                  </p>
                </div>
              )
            ) : (
              // Show recent searches when no query
              recentSearches.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Recent Searches
                    </span>
                    <button
                      onClick={clearRecentSearches}
                      className="text-xs text-muted-foreground hover:text-foreground transition-colors"
                    >
                      Clear all
                    </button>
                  </div>
                  <div className="space-y-1">
                    {recentSearches.map((search) => (
                      <button
                        key={search}
                        onClick={() => handleRecentSearch(search)}
                        className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-secondary transition-colors group"
                      >
                        <span className="text-sm">{search}</span>
                        <button
                          onClick={(e) => removeRecentSearch(search, e)}
                          className="text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </button>
                    ))}
                  </div>
                </div>
              )
            )}
          </div>
        </ScrollArea>

        <div className="border-t border-border/50 p-3">
          <p className="text-xs text-muted-foreground text-center">
            Press <kbd className="px-1.5 py-0.5 rounded bg-secondary text-xs">⌘K</kbd> to open search anytime
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default GlobalSearchModal;
