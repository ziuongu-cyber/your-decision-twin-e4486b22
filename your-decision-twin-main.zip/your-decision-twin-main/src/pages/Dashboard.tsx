import { useState, useEffect, useCallback, useRef } from "react";
import { useLocation, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Target,
  TrendingUp,
  Calendar,
  Plus,
  FileText,
  Sparkles,
  CheckCircle,
} from "lucide-react";
import DashboardLayout from "@/layouts/DashboardLayout";
import TwinScore from "@/components/dashboard/TwinScore";
import StatCard from "@/components/dashboard/StatCard";
import SwipeableDecisionCard from "@/components/mobile/SwipeableDecisionCard";
import OutcomeModal from "@/components/dashboard/OutcomeModal";
import DecisionDetailModal from "@/components/dashboard/DecisionDetailModal";
import { PendingFollowupsWidget } from "@/components/dashboard/PendingFollowupsWidget";
import { OnboardingModal, isOnboardingComplete, markOnboardingComplete } from "@/components/onboarding/OnboardingModal";
import PullToRefresh from "@/components/mobile/PullToRefresh";
import { QuickAddFAB } from "@/components/dashboard/QuickAddFAB";
import { MilestoneCelebration } from "@/components/celebrations/MilestoneCelebration";
import { DashboardSkeleton } from "@/components/common/DashboardSkeleton";
import { ErrorBoundary } from "@/components/common/ErrorBoundary";
import { AtAGlanceWidget } from "@/components/dashboard/AtAGlanceWidget";
import { getAllDecisions, addOutcome, deleteDecision, calculateSuccessRate, Decision, Outcome, getDecision } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import { useReminderNotifications } from "@/hooks/useReminderNotifications";

const Dashboard = () => {
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [outcomeModalOpen, setOutcomeModalOpen] = useState(false);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [selectedDecision, setSelectedDecision] = useState<Decision | null>(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const pendingFollowupsRef = useRef<HTMLDivElement>(null);
  const location = useLocation();
  const { toast } = useToast();
  
  // Enable reminder notifications
  useReminderNotifications();

  // Load decisions function
  const loadDecisions = useCallback(async () => {
    try {
      const allDecisions = await getAllDecisions();
      setDecisions(allDecisions);

      // Check if we should show onboarding (no decisions and not completed before)
      if (allDecisions.length === 0) {
        const completed = await isOnboardingComplete();
        if (!completed) {
          setShowOnboarding(true);
        }
      }
    } catch (error) {
      console.error("Failed to load decisions:", error);
      toast({
        title: "Failed to load decisions",
        description: "Please refresh the page to try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  // Load decisions on mount and check for onboarding
  useEffect(() => {
    loadDecisions();
  }, [loadDecisions]);

  // Pull to refresh handler
  const handleRefresh = useCallback(async () => {
    await loadDecisions();
  }, [loadDecisions]);

  // Show success message if redirected from LogDecision
  useEffect(() => {
    if (location.state?.showSuccess) {
      toast({
        title: "Decision logged! 🎉",
        description: "Your digital twin is learning from your choices.",
      });
      // Clear the state
      window.history.replaceState({}, document.title);
    }
    
    // Handle opening outcome modal from reminder notification
    if (location.state?.openOutcome) {
      const loadAndOpenOutcome = async () => {
        const decision = await getDecision(location.state.openOutcome);
        if (decision) {
          setSelectedDecision(decision);
          setOutcomeModalOpen(true);
        }
        window.history.replaceState({}, document.title);
      };
      loadAndOpenOutcome();
    }
  }, [location.state, toast]);

  // Calculate stats
  const totalDecisions = decisions.length;

  // Calculate active days (unique days with decisions)
  const activeDays = new Set(
    decisions.map((d) => new Date(d.createdAt).toDateString())
  ).size;

  // Twin Score: (total decisions / 50) * 100, max 100%
  const twinScore = Math.min(Math.round((totalDecisions / 50) * 100), 100);

  // Success rate from outcomes
  const successRate = calculateSuccessRate(decisions);

  // Get last 10 decisions for timeline
  const recentDecisions = decisions.slice(0, 10);

  const handleDecisionClick = (decision: Decision) => {
    setSelectedDecision(decision);
    setDetailModalOpen(true);
  };

  const handleAddOutcome = (decisionId: string) => {
    const decision = decisions.find(d => d.id === decisionId);
    if (decision) {
      setSelectedDecision(decision);
      setDetailModalOpen(false);
      setOutcomeModalOpen(true);
    }
  };

  const handleViewOutcome = (decision: Decision) => {
    setSelectedDecision(decision);
    setOutcomeModalOpen(true);
  };

  const handleSaveOutcome = async (decisionId: string, outcome: Outcome) => {
    try {
      const updatedDecision = await addOutcome(decisionId, outcome);
      if (updatedDecision) {
        setDecisions(prev => 
          prev.map(d => d.id === decisionId ? updatedDecision : d)
        );
        toast({
          title: "Outcome saved! 📝",
          description: "Your reflection has been recorded.",
        });
      }
    } catch (error) {
      console.error("Failed to save outcome:", error);
      toast({
        title: "Failed to save outcome",
        description: "Please try again.",
        variant: "destructive",
      });
      throw error;
    }
  };

  const handleDeleteDecision = async (decisionId: string) => {
    try {
      await deleteDecision(decisionId);
      setDecisions(prev => prev.filter(d => d.id !== decisionId));
      toast({
        title: "Decision deleted",
        description: "The decision has been removed.",
      });
    } catch (error) {
      console.error("Failed to delete decision:", error);
      toast({
        title: "Failed to delete",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleReviewFollowups = () => {
    pendingFollowupsRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleMetricClick = (metric: string) => {
    // Could navigate to relevant page or show detailed view
    console.log("Metric clicked:", metric);
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <DashboardSkeleton />
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <ErrorBoundary>
        <PullToRefresh onRefresh={handleRefresh} disabled={isLoading}>
          <div className="max-w-6xl mx-auto space-y-6 md:space-y-8">
        {/* Welcome section with Twin Score */}
        <div className="glass-card rounded-2xl p-4 md:p-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2">
                Welcome back, <span className="gradient-text">Explorer</span>
              </h1>
              <p className="text-muted-foreground">
                {totalDecisions === 0
                  ? "Your digital twin is waiting. Start logging decisions to build your profile."
                  : `Your digital twin has learned from ${totalDecisions} decision${totalDecisions !== 1 ? "s" : ""}.`}
              </p>
            </div>
            <div className="flex justify-center">
              <TwinScore score={twinScore} />
            </div>
          </div>
        </div>

        {/* At a Glance Widget */}
        <AtAGlanceWidget 
          decisions={decisions}
          onReviewFollowups={handleReviewFollowups}
          onMetricClick={handleMetricClick}
        />

        {/* Stats grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <StatCard icon={Target} label="Total Decisions" value={totalDecisions} />
          <StatCard
            icon={TrendingUp}
            label="Twin Score"
            value={twinScore}
            suffix="%"
          />
          <StatCard icon={Calendar} label="Active Days" value={activeDays} />
          <StatCard 
            icon={CheckCircle} 
            label="Success Rate" 
            value={successRate} 
            suffix="%"
          />
        </div>

        {/* Pending Follow-ups Widget */}
        <div ref={pendingFollowupsRef}>
          <PendingFollowupsWidget onAddOutcome={handleAddOutcome} />
        </div>

        {/* Recent Decisions Timeline */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              Recent Decisions
            </h2>
            {totalDecisions > 0 && (
              <Link to="/log-decision">
                <Button variant="outline" size="sm">
                  <Plus className="w-4 h-4" />
                  Log New
                </Button>
              </Link>
            )}
          </div>

          {recentDecisions.length > 0 ? (
            <div className="space-y-3">
              {recentDecisions.map((decision, index) => (
                <div
                  key={decision.id}
                  className="animate-fade-in"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <SwipeableDecisionCard
                    decision={decision}
                    onClick={handleDecisionClick}
                    onAddOutcome={handleAddOutcome}
                  onViewOutcome={handleViewOutcome}
                    onDelete={handleDeleteDecision}
                  />
                </div>
              ))}
            </div>
          ) : (
            // Empty state
            <div className="glass-card rounded-2xl p-12 text-center">
              <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center mx-auto mb-6">
                <Sparkles className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">No decisions yet</h3>
              <p className="text-muted-foreground max-w-sm mx-auto mb-6">
                Your journey starts with a single decision. Log your first one and watch your digital twin come to life!
              </p>
              <Link to="/log-decision">
                <Button variant="hero" size="lg">
                  <Plus className="w-5 h-5" />
                  Log Your First Decision
                </Button>
              </Link>
            </div>
          )}
        </div>

        {/* Quick action CTA - only show when there are some decisions */}
        {totalDecisions > 0 && totalDecisions < 10 && (
          <div className="glass-card rounded-2xl p-6 md:p-8 text-center border border-primary/20">
            <p className="text-muted-foreground mb-4">
              🎯 Log {10 - totalDecisions} more decision{10 - totalDecisions !== 1 ? "s" : ""} to unlock pattern insights!
            </p>
            <Link to="/log-decision">
              <Button variant="hero">
                <Plus className="w-4 h-4" />
                Continue Logging
              </Button>
            </Link>
          </div>
        )}

        {/* Decision Detail Modal */}
        <DecisionDetailModal
          decision={selectedDecision}
          open={detailModalOpen}
          onClose={() => {
            setDetailModalOpen(false);
            setSelectedDecision(null);
          }}
          onAddOutcome={handleAddOutcome}
          onDelete={handleDeleteDecision}
        />

        {/* Outcome Modal */}
        <OutcomeModal
          decision={selectedDecision}
          isOpen={outcomeModalOpen}
          onClose={() => {
            setOutcomeModalOpen(false);
            setSelectedDecision(null);
          }}
          onSave={handleSaveOutcome}
        />

        {/* Onboarding Modal */}
        <OnboardingModal
          open={showOnboarding}
          onComplete={async () => {
            await markOnboardingComplete();
            setShowOnboarding(false);
          }}
          onSkip={async () => {
            await markOnboardingComplete();
            setShowOnboarding(false);
          }}
        />

        {/* Milestone Celebration */}
        <MilestoneCelebration decisionCount={totalDecisions} />

        {/* Quick Add FAB */}
        <QuickAddFAB />
        </div>
      </PullToRefresh>
      </ErrorBoundary>
    </DashboardLayout>
  );
};

export default Dashboard;
