import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { 
  Brain, 
  FileText, 
  TrendingUp, 
  MessageSquare, 
  Sparkles,
  ArrowRight,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";

interface OnboardingModalProps {
  open: boolean;
  onComplete: () => void;
  onSkip: () => void;
}

const steps = [
  {
    id: 1,
    title: "Welcome to Your Digital Twin",
    description: "I learn from your decisions to become your personal advisor",
    icon: Brain,
  },
  {
    id: 2,
    title: "How It Works",
    features: [
      {
        icon: FileText,
        title: "Log Decisions",
        description: "Record your choices as you make them",
      },
      {
        icon: TrendingUp,
        title: "Track Outcomes",
        description: "See how your decisions turn out over time",
      },
      {
        icon: MessageSquare,
        title: "Get Advice",
        description: "Ask me for insights based on your patterns",
      },
    ],
  },
  {
    id: 3,
    title: "Let's Get Started",
    description: "To build your Digital Twin, I need to learn about you",
    cta: "Let's log your first decision!",
    icon: Sparkles,
  },
];

export function OnboardingModal({ open, onComplete, onSkip }: OnboardingModalProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const navigate = useNavigate();

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleStart = () => {
    onComplete();
    navigate("/log-decision");
  };

  const step = steps[currentStep];

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent 
        className="max-w-md p-0 gap-0 overflow-hidden border-primary/20 max-sm:h-[100dvh] max-sm:max-h-[100dvh] max-sm:rounded-none"
        onPointerDownOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
      >
        {/* Skip button */}
        <button
          onClick={onSkip}
          className="absolute right-4 top-4 text-muted-foreground hover:text-foreground transition-colors z-10"
          aria-label="Skip onboarding"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Progress indicators */}
        <div className="flex justify-center gap-2 pt-6 px-6">
          {steps.map((_, idx) => (
            <div
              key={idx}
              className={cn(
                "h-1.5 rounded-full transition-all duration-300",
                idx === currentStep 
                  ? "w-8 bg-primary" 
                  : idx < currentStep 
                  ? "w-4 bg-primary/50"
                  : "w-4 bg-secondary"
              )}
            />
          ))}
        </div>

        {/* Content */}
        <div className="p-6 pt-8">
          {/* Step 1 */}
          {currentStep === 0 && (
            <div className="text-center animate-fade-in">
              <div className="w-24 h-24 mx-auto rounded-3xl gradient-bg flex items-center justify-center mb-6 glow-primary">
                <Brain className="w-12 h-12 text-primary-foreground" />
              </div>
              <h2 className="text-2xl font-bold mb-3">{step.title}</h2>
              <p className="text-muted-foreground text-lg mb-8">
                {step.description}
              </p>
              <Button 
                variant="hero" 
                size="lg" 
                className="w-full"
                onClick={handleNext}
              >
                Next
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          )}

          {/* Step 2 */}
          {currentStep === 1 && (
            <div className="animate-fade-in">
              <h2 className="text-2xl font-bold text-center mb-6">{step.title}</h2>
              <div className="space-y-4 mb-8">
                {step.features?.map((feature, idx) => {
                  const Icon = feature.icon;
                  return (
                    <div 
                      key={idx}
                      className="flex items-start gap-4 p-4 rounded-xl bg-secondary/50 border border-border/50"
                      style={{ animationDelay: `${idx * 100}ms` }}
                    >
                      <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center shrink-0">
                        <Icon className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-1">{feature.title}</h3>
                        <p className="text-sm text-muted-foreground">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
              <Button 
                variant="hero" 
                size="lg" 
                className="w-full"
                onClick={handleNext}
              >
                Next
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          )}

          {/* Step 3 */}
          {currentStep === 2 && (
            <div className="text-center animate-fade-in">
              <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-br from-primary/20 to-accent/20 border border-primary/30 flex items-center justify-center mb-6">
                <Sparkles className="w-12 h-12 text-primary" />
              </div>
              <h2 className="text-2xl font-bold mb-3">{step.title}</h2>
              <p className="text-muted-foreground mb-2">
                {step.description}
              </p>
              <p className="text-lg font-medium text-primary mb-8">
                {step.cta}
              </p>
              <Button 
                variant="hero" 
                size="lg" 
                className="w-full"
                onClick={handleStart}
              >
                Start Logging
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>

        {/* Skip text */}
        <div className="px-6 pb-6 text-center">
          <button
            onClick={onSkip}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Skip for now
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Storage helpers
const ONBOARDING_KEY = "onboarding_complete";

export async function isOnboardingComplete(): Promise<boolean> {
  if (window.storage?.get) {
    const value = await window.storage.get(ONBOARDING_KEY);
    return value === "true";
  }
  return localStorage.getItem(ONBOARDING_KEY) === "true";
}

export async function markOnboardingComplete(): Promise<void> {
  if (window.storage?.set) {
    await window.storage.set(ONBOARDING_KEY, "true");
  } else {
    localStorage.setItem(ONBOARDING_KEY, "true");
  }
}
