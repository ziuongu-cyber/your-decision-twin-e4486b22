import { Decision, Outcome } from "@/lib/storage";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { format, formatDistanceToNow } from "date-fns";
import {
  Briefcase,
  DollarSign,
  Heart,
  Users,
  ShoppingCart,
  RefreshCw,
  HelpCircle,
  Plus,
  Trash2,
  Calendar,
  Eye,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface DecisionModalProps {
  decision: Decision | null;
  open: boolean;
  onClose: () => void;
  onAddOutcome?: (decisionId: string) => void;
  onDelete?: (decisionId: string) => void;
}

const CATEGORY_CONFIG: Record<
  string,
  { icon: React.ElementType; color: string; bgColor: string }
> = {
  Career: { icon: Briefcase, color: "text-blue-400", bgColor: "bg-blue-500/20" },
  Finance: { icon: DollarSign, color: "text-green-400", bgColor: "bg-green-500/20" },
  Health: { icon: Heart, color: "text-red-400", bgColor: "bg-red-500/20" },
  Relationships: { icon: Users, color: "text-pink-400", bgColor: "bg-pink-500/20" },
  Purchase: { icon: ShoppingCart, color: "text-yellow-400", bgColor: "bg-yellow-500/20" },
  "Daily Habit": { icon: RefreshCw, color: "text-cyan-400", bgColor: "bg-cyan-500/20" },
  Other: { icon: HelpCircle, color: "text-gray-400", bgColor: "bg-gray-500/20" },
};

const getConfidenceColor = (confidence: number) => {
  if (confidence <= 3) return "bg-red-500";
  if (confidence <= 5) return "bg-yellow-500";
  if (confidence <= 7) return "bg-blue-500";
  return "bg-green-500";
};

const getOutcomeColor = (rating: number) => {
  if (rating < 4) return "text-red-400 bg-red-500/20";
  if (rating <= 7) return "text-yellow-400 bg-yellow-500/20";
  return "text-green-400 bg-green-500/20";
};

const DecisionModal = ({
  decision,
  open,
  onClose,
  onAddOutcome,
  onDelete,
}: DecisionModalProps) => {
  if (!decision) return null;

  const categoryConfig = CATEGORY_CONFIG[decision.category] || CATEGORY_CONFIG.Other;
  const CategoryIcon = categoryConfig.icon;
  const hasOutcomes = decision.outcomes && decision.outcomes.length > 0;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto max-sm:h-[100dvh] max-sm:max-h-[100dvh] max-sm:rounded-none">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div
              className={cn(
                "w-10 h-10 rounded-lg flex items-center justify-center",
                categoryConfig.bgColor
              )}
            >
              <CategoryIcon className={cn("w-5 h-5", categoryConfig.color)} />
            </div>
            <Badge
              variant="secondary"
              className={cn(categoryConfig.bgColor, categoryConfig.color)}
            >
              {decision.category}
            </Badge>
          </div>
          <DialogTitle className="text-xl">{decision.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 mt-4">
          {/* Choice */}
          <div>
            <h4 className="text-sm font-medium text-muted-foreground mb-1">
              Decision Made
            </h4>
            <p className="text-foreground">{decision.choice}</p>
          </div>

          {/* Confidence */}
          <div>
            <h4 className="text-sm font-medium text-muted-foreground mb-2">
              Confidence Level
            </h4>
            <div className="flex items-center gap-3">
              <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                <div
                  className={cn(
                    "h-full rounded-full transition-all",
                    getConfidenceColor(decision.confidence)
                  )}
                  style={{ width: `${decision.confidence * 10}%` }}
                />
              </div>
              <span className="text-sm font-medium">{decision.confidence}/10</span>
            </div>
          </div>

          {/* Alternatives */}
          {decision.alternatives.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-2">
                Other Options Considered
              </h4>
              <ul className="space-y-1">
                {decision.alternatives.map((alt, idx) => (
                  <li
                    key={idx}
                    className="text-sm text-foreground/80 pl-4 border-l-2 border-border"
                  >
                    {alt}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Context */}
          {decision.context && (
            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-2">
                Context & Thoughts
              </h4>
              <p className="text-sm text-foreground/80 whitespace-pre-wrap bg-secondary/50 rounded-lg p-3">
                {decision.context}
              </p>
            </div>
          )}

          {/* Tags */}
          {decision.tags.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-2">
                Tags
              </h4>
              <div className="flex flex-wrap gap-2">
                {decision.tags.map((tag) => (
                  <Badge key={tag} variant="outline" className="text-xs">
                    #{tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Outcomes */}
          {hasOutcomes && (
            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-3">
                Outcomes ({decision.outcomes.length})
              </h4>
              <div className="space-y-3">
                {decision.outcomes.map((outcome) => (
                  <div
                    key={outcome.id}
                    className="bg-secondary/50 rounded-lg p-3 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className={cn(
                          "px-2 py-1 rounded-md text-sm font-medium",
                          getOutcomeColor(outcome.rating)
                        )}
                      >
                        {outcome.rating}/10
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(outcome.createdAt), {
                          addSuffix: true,
                        })}
                      </span>
                    </div>
                    {outcome.wouldChooseDifferently && (
                      <Badge variant="outline" className="text-xs">
                        Would choose differently
                      </Badge>
                    )}
                    {outcome.reflection && (
                      <p className="text-sm text-foreground/80 italic">
                        "{outcome.reflection}"
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Date */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="w-4 h-4" />
            {format(new Date(decision.createdAt), "MMMM d, yyyy 'at' h:mm a")}
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4 border-t border-border">
            {onAddOutcome && (
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => onAddOutcome(decision.id)}
              >
                <Plus className="w-4 h-4" />
                {hasOutcomes ? "Add Follow-up" : "Add Outcome"}
              </Button>
            )}

            {onDelete && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" size="icon">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Decision?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently delete this decision. This action cannot
                      be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => {
                        onDelete(decision.id);
                        onClose();
                      }}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DecisionModal;
