import { useState, useEffect, useMemo, lazy, Suspense } from "react";
import { useSearchParams, useLocation } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Search,
  ArrowUpDown,
  FileText,
  Briefcase,
  DollarSign,
  Heart,
  Users,
  ShoppingCart,
  RefreshCw,
  HelpCircle,
  ChevronLeft,
  ChevronRight,
  Trash2,
  Plus,
} from "lucide-react";
import { isAfter, isBefore, startOfDay, endOfDay } from "date-fns";
import { formatDistanceToNow } from "date-fns";
import DashboardLayout from "@/layouts/DashboardLayout";
import DecisionDetailModal from "@/components/dashboard/DecisionDetailModal";
import OutcomeModal from "@/components/dashboard/OutcomeModal";
import AdvancedFilters, { FilterState } from "@/components/search/AdvancedFilters";
import { HistorySkeleton } from "@/components/common/DashboardSkeleton";
import { EmptyState } from "@/components/common/EmptyState";
import { ErrorBoundary } from "@/components/common/ErrorBoundary";
import { getAllDecisions, deleteDecision, addOutcome, Decision, Outcome } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import { useDebounce } from "@/hooks/useDebounce";
import { cn } from "@/lib/utils";

const SORT_OPTIONS = [
  { label: "Newest first", value: "newest" },
  { label: "Oldest first", value: "oldest" },
  { label: "Highest confidence", value: "conf-high" },
  { label: "Lowest confidence", value: "conf-low" },
];

const ITEMS_PER_PAGE = 20;

const CATEGORY_CONFIG: Record<
  string,
  { icon: React.ElementType; color: string; bgColor: string }
> = {
  Career: { icon: Briefcase, color: "text-blue-400", bgColor: "bg-blue-500/20" },
  Finance: { icon: DollarSign, color: "text-green-400", bgColor: "bg-green-500/20" },
  Health: { icon: Heart, color: "text-red-400", bgColor: "bg-red-500/20" },
  Relationships: { icon: Users, color: "text-pink-400", bgColor: "bg-pink-500/20" },
  Purchase: { icon: ShoppingCart, color: "text-yellow-400", bgColor: "bg-yellow-500/20" },
  "Daily Habit": { icon: RefreshCw, color: "text-cyan-400", bgColor: "bg-cyan-500/20" },
  Other: { icon: HelpCircle, color: "text-gray-400", bgColor: "bg-gray-500/20" },
};

const getConfidenceColor = (confidence: number) => {
  if (confidence <= 3) return "bg-red-500";
  if (confidence <= 5) return "bg-yellow-500";
  if (confidence <= 7) return "bg-blue-500";
  return "bg-green-500";
};

const DEFAULT_FILTERS: FilterState = {
  categories: [],
  confidenceRange: [1, 10],
  outcomeFilters: [],
  dateRange: undefined,
  tags: [],
};

const History = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const location = useLocation();
  const [allDecisions, setAllDecisions] = useState<Decision[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "");
  const [sortBy, setSortBy] = useState(searchParams.get("sort") || "newest");
  const [currentPage, setCurrentPage] = useState(
    parseInt(searchParams.get("page") || "1", 10)
  );
  const [selectedDecision, setSelectedDecision] = useState<Decision | null>(null);
  const [outcomeModalOpen, setOutcomeModalOpen] = useState(false);
  const [outcomeDecision, setOutcomeDecision] = useState<Decision | null>(null);
  const { toast } = useToast();

  // Debounce search query for performance
  const debouncedSearchQuery = useDebounce(searchQuery, 300);

  // Initialize filters from URL params
  const [filters, setFilters] = useState<FilterState>(() => {
    const categories = searchParams.get("categories")?.split(",").filter(Boolean) || [];
    const confMin = parseInt(searchParams.get("confMin") || "1", 10);
    const confMax = parseInt(searchParams.get("confMax") || "10", 10);
    const outcomeFilters = searchParams.get("outcomes")?.split(",").filter(Boolean) || [];
    const tags = searchParams.get("tags")?.split(",").filter(Boolean) || [];
    const dateFrom = searchParams.get("from");
    const dateTo = searchParams.get("to");

    return {
      categories,
      confidenceRange: [confMin, confMax] as [number, number],
      outcomeFilters,
      dateRange: dateFrom || dateTo
        ? {
            from: dateFrom ? new Date(dateFrom) : undefined,
            to: dateTo ? new Date(dateTo) : undefined,
          }
        : undefined,
      tags,
    };
  });

  // Load all decisions once
  useEffect(() => {
    const loadDecisions = async () => {
      try {
        const decisions = await getAllDecisions();
        setAllDecisions(decisions);

        // Check if we should open a specific decision
        if (location.state?.openDecision) {
          const decision = decisions.find(d => d.id === location.state.openDecision.id);
          if (decision) {
            setSelectedDecision(decision);
          }
        }
      } catch (error) {
        console.error("Failed to load decisions:", error);
        toast({
          title: "Failed to load history",
          description: "Please refresh the page to try again.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };
    loadDecisions();
  }, [toast, location.state]);

  // Persist filter state to URL
  useEffect(() => {
    const params = new URLSearchParams();

    if (searchQuery) params.set("q", searchQuery);
    if (sortBy !== "newest") params.set("sort", sortBy);
    if (currentPage > 1) params.set("page", currentPage.toString());
    if (filters.categories.length > 0) params.set("categories", filters.categories.join(","));
    if (filters.confidenceRange[0] !== 1) params.set("confMin", filters.confidenceRange[0].toString());
    if (filters.confidenceRange[1] !== 10) params.set("confMax", filters.confidenceRange[1].toString());
    if (filters.outcomeFilters.length > 0) params.set("outcomes", filters.outcomeFilters.join(","));
    if (filters.tags.length > 0) params.set("tags", filters.tags.join(","));
    if (filters.dateRange?.from) params.set("from", filters.dateRange.from.toISOString().split("T")[0]);
    if (filters.dateRange?.to) params.set("to", filters.dateRange.to.toISOString().split("T")[0]);

    setSearchParams(params, { replace: true });
  }, [searchQuery, sortBy, currentPage, filters, setSearchParams]);

  // Filter and sort decisions in memory
  const filteredDecisions = useMemo(() => {
    let result = [...allDecisions];

    // Search filter (use debounced value)
    if (debouncedSearchQuery.trim()) {
      const query = debouncedSearchQuery.toLowerCase();
      result = result.filter(
        (d) =>
          d.title.toLowerCase().includes(query) ||
          d.choice.toLowerCase().includes(query) ||
          d.context.toLowerCase().includes(query) ||
          d.alternatives.some((alt) => alt.toLowerCase().includes(query)) ||
          d.tags.some((tag) => tag.toLowerCase().includes(query))
      );
    }

    // Category filter (multi-select)
    if (filters.categories.length > 0) {
      result = result.filter((d) => filters.categories.includes(d.category));
    }

    // Confidence range filter
    result = result.filter(
      (d) =>
        d.confidence >= filters.confidenceRange[0] &&
        d.confidence <= filters.confidenceRange[1]
    );

    // Outcome filters
    if (filters.outcomeFilters.length > 0) {
      result = result.filter((d) => {
        const hasOutcomes = d.outcomes && d.outcomes.length > 0;
        const avgRating = hasOutcomes
          ? d.outcomes.reduce((sum, o) => sum + o.rating, 0) / d.outcomes.length
          : 0;

        return filters.outcomeFilters.some((filter) => {
          switch (filter) {
            case "with":
              return hasOutcomes;
            case "without":
              return !hasOutcomes;
            case "positive":
              return hasOutcomes && avgRating >= 7;
            case "negative":
              return hasOutcomes && avgRating <= 4;
            default:
              return true;
          }
        });
      });
    }

    // Date range filter
    if (filters.dateRange?.from || filters.dateRange?.to) {
      result = result.filter((d) => {
        const decisionDate = new Date(d.createdAt);
        if (filters.dateRange?.from && isBefore(decisionDate, startOfDay(filters.dateRange.from))) {
          return false;
        }
        if (filters.dateRange?.to && isAfter(decisionDate, endOfDay(filters.dateRange.to))) {
          return false;
        }
        return true;
      });
    }

    // Tags filter (multi-select)
    if (filters.tags.length > 0) {
      result = result.filter((d) =>
        filters.tags.some((tag) => d.tags.includes(tag))
      );
    }

    // Sort
    switch (sortBy) {
      case "oldest":
        result.sort(
          (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
        );
        break;
      case "conf-high":
        result.sort((a, b) => b.confidence - a.confidence);
        break;
      case "conf-low":
        result.sort((a, b) => a.confidence - b.confidence);
        break;
      default: // newest
        result.sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
    }

    return result;
  }, [allDecisions, debouncedSearchQuery, filters, sortBy]);

  // Pagination
  const totalPages = Math.ceil(filteredDecisions.length / ITEMS_PER_PAGE);
  const paginatedDecisions = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredDecisions.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredDecisions, currentPage]);

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearchQuery, filters, sortBy]);

  const handleDelete = async (id: string) => {
    try {
      await deleteDecision(id);
      setAllDecisions((prev) => prev.filter((d) => d.id !== id));
      toast({
        title: "Decision deleted",
        description: "The decision has been removed from your history.",
      });
    } catch (error) {
      console.error("Failed to delete decision:", error);
      toast({
        title: "Failed to delete",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleAddOutcome = (id: string) => {
    const decision = allDecisions.find(d => d.id === id);
    if (decision) {
      setOutcomeDecision(decision);
      setOutcomeModalOpen(true);
      setSelectedDecision(null);
    }
  };

  const handleSaveOutcome = async (decisionId: string, outcome: Outcome) => {
    try {
      const updatedDecision = await addOutcome(decisionId, outcome);
      if (updatedDecision) {
        setAllDecisions(prev => 
          prev.map(d => d.id === decisionId ? updatedDecision : d)
        );
        toast({
          title: "Outcome saved! 📝",
          description: "Your reflection has been recorded.",
        });
      }
    } catch (error) {
      console.error("Failed to save outcome:", error);
      toast({
        title: "Failed to save outcome",
        description: "Please try again.",
        variant: "destructive",
      });
      throw error;
    }
  };

  const handleClearFilters = () => {
    setFilters(DEFAULT_FILTERS);
    setSearchQuery("");
    setSortBy("newest");
  };

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Decision History</h1>
          <p className="text-muted-foreground">
            Browse and search through all your logged decisions
          </p>
        </div>

        {/* Quick Filters */}
        <div className="glass-card rounded-xl p-4">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search decisions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-secondary border-border/50"
              />
            </div>

            {/* Sort */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full lg:w-48 bg-secondary border-border/50">
                <ArrowUpDown className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border-border">
                {SORT_OPTIONS.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Results count */}
          <div className="mt-3 text-sm text-muted-foreground">
            Showing {paginatedDecisions.length} of {filteredDecisions.length} decision{filteredDecisions.length !== 1 ? "s" : ""}
            {filteredDecisions.length !== allDecisions.length && (
              <span className="text-primary ml-1">
                (filtered from {allDecisions.length} total)
              </span>
            )}
          </div>
        </div>

        {/* Advanced Filters */}
        <AdvancedFilters
          decisions={allDecisions}
          filters={filters}
          onChange={setFilters}
          onClear={handleClearFilters}
        />

        {/* Content */}
        {isLoading ? (
          <HistorySkeleton />
        ) : paginatedDecisions.length > 0 ? (
          <>
            {/* Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {paginatedDecisions.map((decision) => {
                const categoryConfig =
                  CATEGORY_CONFIG[decision.category] || CATEGORY_CONFIG.Other;
                const CategoryIcon = categoryConfig.icon;

                return (
                  <button
                    key={decision.id}
                    onClick={() => setSelectedDecision(decision)}
                    className="glass-card rounded-xl p-5 text-left hover:shadow-lg hover:shadow-primary/10 hover:scale-[1.02] transition-all duration-300 group"
                  >
                    {/* Header */}
                    <div className="flex items-start gap-3 mb-3">
                      <div
                        className={cn(
                          "w-10 h-10 rounded-lg flex items-center justify-center shrink-0",
                          categoryConfig.bgColor
                        )}
                      >
                        <CategoryIcon
                          className={cn("w-5 h-5", categoryConfig.color)}
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium truncate group-hover:text-primary transition-colors">
                          {decision.title}
                        </h3>
                        <p className="text-sm text-muted-foreground truncate">
                          {decision.choice}
                        </p>
                      </div>
                    </div>

                    {/* Confidence bar */}
                    <div className="flex items-center gap-2 mb-3">
                      <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
                        <div
                          className={cn(
                            "h-full rounded-full",
                            getConfidenceColor(decision.confidence)
                          )}
                          style={{ width: `${decision.confidence * 10}%` }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {decision.confidence}/10
                      </span>
                    </div>

                    {/* Footer */}
                    <div className="flex items-center justify-between">
                      <div className="flex flex-wrap gap-1">
                        <Badge
                          variant="secondary"
                          className={cn(
                            "text-xs",
                            categoryConfig.bgColor,
                            categoryConfig.color
                          )}
                        >
                          {decision.category}
                        </Badge>
                        {decision.tags.slice(0, 2).map((tag) => (
                          <Badge
                            key={tag}
                            variant="outline"
                            className="text-xs"
                          >
                            #{tag}
                          </Badge>
                        ))}
                        {decision.tags.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{decision.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground shrink-0">
                        {formatDistanceToNow(new Date(decision.createdAt), {
                          addSuffix: true,
                        })}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 pt-4">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>

                {Array.from({ length: totalPages }, (_, i) => i + 1)
                  .filter(
                    (page) =>
                      page === 1 ||
                      page === totalPages ||
                      Math.abs(page - currentPage) <= 1
                  )
                  .map((page, idx, arr) => (
                    <div key={page} className="flex items-center">
                      {idx > 0 && arr[idx - 1] !== page - 1 && (
                        <span className="px-2 text-muted-foreground">...</span>
                      )}
                      <Button
                        variant={currentPage === page ? "default" : "outline"}
                        size="icon"
                        onClick={() => setCurrentPage(page)}
                        className={cn(
                          currentPage === page && "gradient-bg border-0"
                        )}
                      >
                        {page}
                      </Button>
                    </div>
                  ))}

                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            )}
          </>
        ) : (
          <div className="glass-card rounded-2xl p-12 text-center">
            <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mx-auto mb-4">
              <FileText className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium mb-2">No decisions found</h3>
            <p className="text-muted-foreground">
              {allDecisions.length === 0
                ? "Start logging decisions to see them here"
                : "Try adjusting your search or filters"}
            </p>
          </div>
        )}

        <DecisionDetailModal
          decision={selectedDecision}
          open={!!selectedDecision}
          onClose={() => setSelectedDecision(null)}
          onAddOutcome={handleAddOutcome}
          onDelete={handleDelete}
        />

        {/* Outcome Modal */}
        <OutcomeModal
          decision={outcomeDecision}
          isOpen={outcomeModalOpen}
          onClose={() => {
            setOutcomeModalOpen(false);
            setOutcomeDecision(null);
          }}
          onSave={handleSaveOutcome}
        />
      </div>
    </DashboardLayout>
  );
};

export default History;
