import { useState, useRef } from "react";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import {
  Download,
  FileJson,
  FileSpreadsheet,
  FileText,
  Upload,
  Check,
  AlertTriangle,
  Loader2,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  getAllDecisions,
  getInsights,
  getReminders,
  saveDecision,
  saveInsights,
  saveReminders,
  Decision,
  Insights,
  Reminder,
} from "@/lib/storage";

interface DataExportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface ExportData {
  version: string;
  exportedAt: string;
  decisions: Decision[];
  insights: Insights | null;
  reminders: Reminder[];
}

interface ImportPreview {
  decisions: number;
  insights: boolean;
  reminders: number;
  isValid: boolean;
  errors: string[];
}

const DataExportModal = ({ open, onOpenChange }: DataExportModalProps) => {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importPreview, setImportPreview] = useState<ImportPreview | null>(null);
  const [importData, setImportData] = useState<ExportData | null>(null);
  const [importMode, setImportMode] = useState<"merge" | "replace">("merge");

  const downloadFile = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleExportJSON = async () => {
    setIsExporting(true);
    try {
      const decisions = await getAllDecisions();
      const insights = await getInsights();
      const reminders = await getReminders();

      const exportData: ExportData = {
        version: "1.0",
        exportedAt: new Date().toISOString(),
        decisions,
        insights,
        reminders,
      };

      const filename = `digital-twin-backup-${format(new Date(), "yyyy-MM-dd")}.json`;
      downloadFile(JSON.stringify(exportData, null, 2), filename, "application/json");

      toast({
        title: "Export successful",
        description: `Downloaded ${decisions.length} decisions as JSON`,
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Could not export data",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportCSV = async () => {
    setIsExporting(true);
    try {
      const decisions = await getAllDecisions();

      const headers = [
        "Date",
        "Title",
        "Category",
        "Choice",
        "Alternatives",
        "Confidence",
        "Context",
        "Tags",
        "Outcome Rating",
        "Would Choose Differently",
        "Reflection",
      ];

      const rows = decisions.map((d) => {
        const latestOutcome = d.outcomes?.[d.outcomes.length - 1];
        return [
          format(new Date(d.createdAt), "yyyy-MM-dd HH:mm"),
          `"${d.title.replace(/"/g, '""')}"`,
          d.category,
          `"${d.choice.replace(/"/g, '""')}"`,
          `"${d.alternatives.join("; ").replace(/"/g, '""')}"`,
          d.confidence.toString(),
          `"${d.context.replace(/"/g, '""')}"`,
          `"${d.tags.join(", ")}"`,
          latestOutcome?.rating?.toString() || "",
          latestOutcome?.wouldChooseDifferently ? "Yes" : latestOutcome ? "No" : "",
          latestOutcome ? `"${latestOutcome.reflection.replace(/"/g, '""')}"` : "",
        ].join(",");
      });

      const csv = [headers.join(","), ...rows].join("\n");
      const filename = `digital-twin-export-${format(new Date(), "yyyy-MM-dd")}.csv`;
      downloadFile(csv, filename, "text/csv");

      toast({
        title: "Export successful",
        description: `Downloaded ${decisions.length} decisions as CSV`,
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Could not export data",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportPDF = async () => {
    setIsExporting(true);
    try {
      const decisions = await getAllDecisions();
      const insights = await getInsights();

      // Create a printable HTML document
      const printWindow = window.open("", "_blank");
      if (!printWindow) {
        toast({
          title: "Popup blocked",
          description: "Please allow popups to export PDF",
          variant: "destructive",
        });
        return;
      }

      const totalDecisions = decisions.length;
      const decisionsWithOutcomes = decisions.filter((d) => d.outcomes?.length > 0).length;
      const avgConfidence =
        decisions.length > 0
          ? Math.round(decisions.reduce((sum, d) => sum + d.confidence, 0) / decisions.length)
          : 0;
      const avgOutcomeRating =
        decisions.flatMap((d) => d.outcomes || []).length > 0
          ? (
              decisions.flatMap((d) => d.outcomes || []).reduce((sum, o) => sum + o.rating, 0) /
              decisions.flatMap((d) => d.outcomes || []).length
            ).toFixed(1)
          : "N/A";

      const html = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>Digital Twin Report - ${format(new Date(), "yyyy-MM-dd")}</title>
          <style>
            * { box-sizing: border-box; }
            body { 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              line-height: 1.6;
              color: #1a1a2e;
              max-width: 800px;
              margin: 0 auto;
              padding: 40px 20px;
            }
            h1 { color: #7c3aed; margin-bottom: 8px; }
            h2 { color: #4a4a6a; border-bottom: 2px solid #7c3aed; padding-bottom: 8px; margin-top: 40px; }
            h3 { color: #1a1a2e; margin: 20px 0 10px; }
            .subtitle { color: #666; margin-bottom: 30px; }
            .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin: 20px 0; }
            .stat-card { 
              background: #f8f7ff; 
              padding: 16px; 
              border-radius: 8px; 
              text-align: center;
              border: 1px solid #e0e0f0;
            }
            .stat-value { font-size: 24px; font-weight: bold; color: #7c3aed; }
            .stat-label { font-size: 12px; color: #666; }
            .decision-card {
              border: 1px solid #e0e0f0;
              border-radius: 8px;
              padding: 16px;
              margin: 16px 0;
              page-break-inside: avoid;
            }
            .decision-header { display: flex; justify-content: space-between; align-items: center; }
            .decision-title { font-weight: 600; font-size: 16px; }
            .decision-meta { color: #666; font-size: 12px; }
            .badge { 
              display: inline-block;
              background: #7c3aed;
              color: white;
              padding: 2px 8px;
              border-radius: 12px;
              font-size: 11px;
              margin-right: 4px;
            }
            .badge-outline { background: transparent; border: 1px solid #7c3aed; color: #7c3aed; }
            .choice { background: #f0fdf4; padding: 8px 12px; border-radius: 6px; margin: 8px 0; }
            .outcome { background: #fef3c7; padding: 12px; border-radius: 6px; margin-top: 12px; }
            .insight-card { background: #f8f7ff; padding: 12px; border-radius: 6px; margin: 8px 0; }
            @media print {
              .stats-grid { grid-template-columns: repeat(4, 1fr); }
              .decision-card { break-inside: avoid; }
            }
          </style>
        </head>
        <body>
          <h1>🧠 Digital Twin Report</h1>
          <p class="subtitle">Generated on ${format(new Date(), "MMMM d, yyyy 'at' h:mm a")}</p>
          
          <h2>📊 Summary Statistics</h2>
          <div class="stats-grid">
            <div class="stat-card">
              <div class="stat-value">${totalDecisions}</div>
              <div class="stat-label">Total Decisions</div>
            </div>
            <div class="stat-card">
              <div class="stat-value">${decisionsWithOutcomes}</div>
              <div class="stat-label">With Outcomes</div>
            </div>
            <div class="stat-card">
              <div class="stat-value">${avgConfidence}%</div>
              <div class="stat-label">Avg. Confidence</div>
            </div>
            <div class="stat-card">
              <div class="stat-value">${avgOutcomeRating}</div>
              <div class="stat-label">Avg. Rating</div>
            </div>
          </div>

          ${
            insights
              ? `
          <h2>💡 Top Insights</h2>
          ${insights.topPatterns
            .slice(0, 3)
            .map(
              (p) => `
            <div class="insight-card">
              <strong>${p.pattern}</strong>
              <span class="badge badge-outline">${p.confidence} confidence</span>
            </div>
          `
            )
            .join("")}
          
          ${
            insights.recommendations.length > 0
              ? `
            <h3>Recommendations</h3>
            <ul>
              ${insights.recommendations.map((r) => `<li>${r}</li>`).join("")}
            </ul>
          `
              : ""
          }
          `
              : ""
          }

          <h2>📋 All Decisions</h2>
          ${decisions
            .map(
              (d) => `
            <div class="decision-card">
              <div class="decision-header">
                <span class="decision-title">${d.title}</span>
                <span class="decision-meta">${format(new Date(d.createdAt), "MMM d, yyyy")}</span>
              </div>
              <div style="margin: 8px 0;">
                <span class="badge">${d.category}</span>
                ${d.tags.map((t) => `<span class="badge badge-outline">${t}</span>`).join("")}
              </div>
              <div class="choice">
                <strong>Choice:</strong> ${d.choice}
              </div>
              ${d.alternatives.length > 0 ? `<p><strong>Alternatives:</strong> ${d.alternatives.join(", ")}</p>` : ""}
              <p><strong>Confidence:</strong> ${d.confidence}%</p>
              ${d.context ? `<p><strong>Context:</strong> ${d.context}</p>` : ""}
              ${
                d.outcomes?.length > 0
                  ? `
                <div class="outcome">
                  <strong>Latest Outcome</strong><br/>
                  Rating: ${d.outcomes[d.outcomes.length - 1].rating}/10<br/>
                  ${d.outcomes[d.outcomes.length - 1].reflection}
                </div>
              `
                  : ""
              }
            </div>
          `
            )
            .join("")}
        </body>
        </html>
      `;

      printWindow.document.write(html);
      printWindow.document.close();
      printWindow.print();

      toast({
        title: "PDF ready",
        description: "Use your browser's print dialog to save as PDF",
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Could not generate PDF",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const validateImportData = (data: unknown): ImportPreview => {
    const errors: string[] = [];
    let decisions = 0;
    let insights = false;
    let reminders = 0;

    if (!data || typeof data !== "object") {
      return { decisions: 0, insights: false, reminders: 0, isValid: false, errors: ["Invalid JSON structure"] };
    }

    const d = data as Record<string, unknown>;

    if (!d.version) {
      errors.push("Missing version field");
    }

    if (Array.isArray(d.decisions)) {
      decisions = d.decisions.length;
      for (const dec of d.decisions) {
        if (
          !dec.id ||
          !dec.title ||
          !dec.choice ||
          !dec.category ||
          typeof dec.confidence !== "number"
        ) {
          errors.push("One or more decisions have invalid structure");
          break;
        }
      }
    } else if (d.decisions !== undefined) {
      errors.push("Decisions must be an array");
    }

    if (d.insights && typeof d.insights === "object") {
      insights = true;
    }

    if (Array.isArray(d.reminders)) {
      reminders = d.reminders.length;
    }

    return {
      decisions,
      insights,
      reminders,
      isValid: errors.length === 0 && decisions > 0,
      errors,
    };
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        const preview = validateImportData(data);
        setImportPreview(preview);
        if (preview.isValid) {
          setImportData(data as ExportData);
        } else {
          setImportData(null);
        }
      } catch {
        setImportPreview({
          decisions: 0,
          insights: false,
          reminders: 0,
          isValid: false,
          errors: ["Invalid JSON file"],
        });
        setImportData(null);
      }
    };
    reader.readAsText(file);
  };

  const handleImport = async () => {
    if (!importData) return;

    setIsImporting(true);
    try {
      if (importMode === "merge") {
        // Merge: add new decisions, skip duplicates
        const existingDecisions = await getAllDecisions();
        const existingIds = new Set(existingDecisions.map((d) => d.id));

        let imported = 0;
        for (const decision of importData.decisions) {
          if (!existingIds.has(decision.id)) {
            await saveDecision(decision);
            imported++;
          }
        }

        if (importData.insights && !await getInsights()) {
          await saveInsights(importData.insights);
        }

        toast({
          title: "Import successful",
          description: `Imported ${imported} new decisions (${importData.decisions.length - imported} skipped as duplicates)`,
        });
      } else {
        // Replace: overwrite all data
        for (const decision of importData.decisions) {
          await saveDecision(decision);
        }

        if (importData.insights) {
          await saveInsights(importData.insights);
        }

        if (importData.reminders) {
          await saveReminders(importData.reminders);
        }

        toast({
          title: "Import successful",
          description: `Imported ${importData.decisions.length} decisions`,
        });
      }

      // Reset state
      setImportPreview(null);
      setImportData(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    } catch (error) {
      toast({
        title: "Import failed",
        description: "Could not import data",
        variant: "destructive",
      });
    } finally {
      setIsImporting(false);
    }
  };

  const cancelImport = () => {
    setImportPreview(null);
    setImportData(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-sm:h-[100dvh] max-sm:max-h-[100dvh] max-sm:rounded-none">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="w-5 h-5" />
            Export & Backup
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[70vh] max-sm:max-h-[calc(100dvh-120px)]">
          <div className="space-y-6 pr-4">
            {/* Export Options */}
            <div className="space-y-3">
              <h3 className="font-medium text-sm text-muted-foreground">Export Options</h3>

              <Button
                variant="outline"
                className="w-full justify-start gap-3 h-auto py-3"
                onClick={handleExportJSON}
                disabled={isExporting}
              >
                <FileJson className="w-5 h-5 text-blue-500" />
                <div className="text-left">
                  <div className="font-medium">Export All Data (JSON)</div>
                  <div className="text-xs text-muted-foreground">
                    Complete backup including decisions, outcomes, and insights
                  </div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="w-full justify-start gap-3 h-auto py-3"
                onClick={handleExportCSV}
                disabled={isExporting}
              >
                <FileSpreadsheet className="w-5 h-5 text-green-500" />
                <div className="text-left">
                  <div className="font-medium">Export as CSV</div>
                  <div className="text-xs text-muted-foreground">
                    Spreadsheet-friendly format for Excel/Google Sheets
                  </div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="w-full justify-start gap-3 h-auto py-3"
                onClick={handleExportPDF}
                disabled={isExporting}
              >
                <FileText className="w-5 h-5 text-red-500" />
                <div className="text-left">
                  <div className="font-medium">Export as PDF Report</div>
                  <div className="text-xs text-muted-foreground">
                    Printable report with stats, insights, and all decisions
                  </div>
                </div>
              </Button>
            </div>

            {/* Import Section */}
            <div className="space-y-3 pt-4 border-t">
              <h3 className="font-medium text-sm text-muted-foreground">Import Data</h3>

              {!importPreview ? (
                <div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".json"
                    onChange={handleFileSelect}
                    className="hidden"
                    id="import-file"
                  />
                  <Button
                    variant="outline"
                    className="w-full justify-start gap-3 h-auto py-3"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="w-5 h-5 text-purple-500" />
                    <div className="text-left">
                      <div className="font-medium">Import from JSON</div>
                      <div className="text-xs text-muted-foreground">
                        Restore from a previous backup file
                      </div>
                    </div>
                  </Button>
                </div>
              ) : (
                <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                  <div className="flex items-start gap-3">
                    {importPreview.isValid ? (
                      <Check className="w-5 h-5 text-green-500 mt-0.5" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-yellow-500 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <p className="font-medium">
                        {importPreview.isValid ? "Valid backup file" : "Invalid backup file"}
                      </p>
                      {importPreview.isValid ? (
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Badge variant="secondary">{importPreview.decisions} decisions</Badge>
                          {importPreview.insights && <Badge variant="secondary">Insights included</Badge>}
                          {importPreview.reminders > 0 && (
                            <Badge variant="secondary">{importPreview.reminders} reminders</Badge>
                          )}
                        </div>
                      ) : (
                        <ul className="text-sm text-destructive mt-2">
                          {importPreview.errors.map((err, i) => (
                            <li key={i}>• {err}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>

                  {importPreview.isValid && (
                    <div className="space-y-3">
                      <Label className="text-sm font-medium">Import Mode</Label>
                      <RadioGroup
                        value={importMode}
                        onValueChange={(v) => setImportMode(v as "merge" | "replace")}
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="merge" id="merge" />
                          <Label htmlFor="merge" className="font-normal">
                            Merge with existing data (skip duplicates)
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="replace" id="replace" />
                          <Label htmlFor="replace" className="font-normal">
                            Replace existing data
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Button variant="outline" onClick={cancelImport} className="flex-1">
                      Cancel
                    </Button>
                    {importPreview.isValid && (
                      <Button onClick={handleImport} disabled={isImporting} className="flex-1">
                        {isImporting ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin mr-2" />
                            Importing...
                          </>
                        ) : (
                          "Import"
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};

export default DataExportModal;
