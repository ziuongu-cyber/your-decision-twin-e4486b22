import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { 
  getSharedDecision, 
  addComment, 
  SharedDecision as SharedDecisionType, 
  SharedComment 
} from "@/lib/sharing";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import {
  Briefcase,
  DollarSign,
  Heart,
  Users,
  ShoppingCart,
  RefreshCw,
  HelpCircle,
  MessageSquare,
  Send,
  Clock,
  ArrowLeft,
  Sparkles,
  CheckCircle,
  ListChecks,
  User,
  Copy,
  AlertCircle,
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";

const CATEGORY_CONFIG: Record<
  string,
  { icon: React.ElementType; color: string; bgColor: string }
> = {
  Career: { icon: Briefcase, color: "text-blue-400", bgColor: "bg-blue-500/20" },
  Finance: { icon: DollarSign, color: "text-green-400", bgColor: "bg-green-500/20" },
  Health: { icon: Heart, color: "text-red-400", bgColor: "bg-red-500/20" },
  Relationships: { icon: Users, color: "text-pink-400", bgColor: "bg-pink-500/20" },
  Purchase: { icon: ShoppingCart, color: "text-yellow-400", bgColor: "bg-yellow-500/20" },
  "Daily Habit": { icon: RefreshCw, color: "text-cyan-400", bgColor: "bg-cyan-500/20" },
  Other: { icon: HelpCircle, color: "text-gray-400", bgColor: "bg-gray-500/20" },
};

const getConfidenceColor = (confidence: number) => {
  if (confidence <= 3) return "bg-red-500";
  if (confidence <= 5) return "bg-yellow-500";
  if (confidence <= 7) return "bg-blue-500";
  return "bg-green-500";
};

const SharedDecision = () => {
  const { shareId } = useParams<{ shareId: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [sharedDecision, setSharedDecision] = useState<SharedDecisionType | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [authorName, setAuthorName] = useState("");
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [comments, setComments] = useState<SharedComment[]>([]);

  useEffect(() => {
    loadSharedDecision();
  }, [shareId]);

  const loadSharedDecision = async () => {
    if (!shareId) {
      setNotFound(true);
      setLoading(false);
      return;
    }

    try {
      const shared = await getSharedDecision(shareId);
      if (!shared) {
        setNotFound(true);
      } else {
        setSharedDecision(shared);
        setComments(shared.comments);
      }
    } catch (error) {
      console.error("Error loading shared decision:", error);
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitComment = async () => {
    if (!shareId || !authorName.trim() || !comment.trim()) {
      toast({
        title: "Please fill in all fields",
        description: "Enter your name and your advice",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    try {
      const newComment = await addComment(shareId, authorName.trim(), comment.trim());
      if (newComment) {
        setComments(prev => [...prev, newComment]);
        setComment("");
        toast({
          title: "Advice shared!",
          description: "Your friend will see your comment",
        });
      }
    } catch (error) {
      toast({
        title: "Failed to submit",
        description: "Please try again",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleLogSimilar = () => {
    if (!sharedDecision) return;
    navigate("/log-decision", { 
      state: { 
        prefill: {
          category: sharedDecision.decision.category,
          tags: sharedDecision.decision.tags,
        }
      }
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (notFound || !sharedDecision) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center space-y-4">
            <AlertCircle className="w-16 h-16 mx-auto text-muted-foreground" />
            <h1 className="text-2xl font-bold">Link Not Found</h1>
            <p className="text-muted-foreground">
              This share link may have expired, been revoked, or doesn't exist.
            </p>
            <Button onClick={() => navigate("/")}>
              Go to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { decision } = sharedDecision;
  const categoryConfig = CATEGORY_CONFIG[decision.category] || CATEGORY_CONFIG.Other;
  const CategoryIcon = categoryConfig.icon;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur-sm">
        <div className="container max-w-3xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="font-semibold">Shared Decision</span>
          </div>
          <Badge variant="secondary" className="gap-1">
            <Clock className="w-3 h-3" />
            Expires {formatDistanceToNow(new Date(sharedDecision.expiresAt), { addSuffix: true })}
          </Badge>
        </div>
      </header>

      <main className="container max-w-3xl mx-auto px-4 py-8 space-y-6">
        {/* Decision Card */}
        <Card>
          <CardHeader>
            <div className="flex items-start gap-4">
              <div
                className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center shrink-0",
                  categoryConfig.bgColor
                )}
              >
                <CategoryIcon className={cn("w-6 h-6", categoryConfig.color)} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Badge
                    variant="secondary"
                    className={cn("text-xs", categoryConfig.bgColor, categoryConfig.color)}
                  >
                    {decision.category}
                  </Badge>
                </div>
                <CardTitle className="text-xl">{decision.title}</CardTitle>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Metadata */}
            <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
              <span>{format(new Date(decision.createdAt), "MMM d, yyyy")}</span>
              <div className="flex items-center gap-2">
                <div className={cn("w-2 h-2 rounded-full", getConfidenceColor(decision.confidence))} />
                <span>Confidence: {decision.confidence}/10</span>
              </div>
            </div>

            <Separator />

            {/* Choice */}
            <section>
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-primary" />
                Their Choice
              </h3>
              <div className="bg-primary/10 border border-primary/20 rounded-xl p-4">
                <p className="font-medium">{decision.choice}</p>
              </div>
            </section>

            {/* Alternatives */}
            {decision.alternatives.length > 0 && (
              <section>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                  <ListChecks className="w-4 h-4" />
                  Alternatives Considered
                </h3>
                <ul className="space-y-2">
                  {decision.alternatives.map((alt, idx) => (
                    <li
                      key={idx}
                      className="flex items-start gap-3 text-foreground/80"
                    >
                      <span className="w-5 h-5 rounded-full bg-secondary flex items-center justify-center text-xs text-muted-foreground shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span>{alt}</span>
                    </li>
                  ))}
                </ul>
              </section>
            )}

            {/* Context (if full share) */}
            {sharedDecision.shareType === "full" && decision.context && (
              <section>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                  Their Thinking
                </h3>
                <div className="bg-secondary/50 rounded-xl p-4 text-foreground/80 whitespace-pre-wrap">
                  {decision.context}
                </div>
              </section>
            )}

            {/* Tags */}
            {decision.tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {decision.tags.map((tag) => (
                  <Badge key={tag} variant="outline" className="text-xs">
                    #{tag}
                  </Badge>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Comment Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <MessageSquare className="w-5 h-5 text-primary" />
              Share Your Advice
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Input
                placeholder="Your name"
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                className="max-w-xs"
              />
            </div>
            <div className="space-y-2">
              <Textarea
                placeholder="What would you advise? Share your perspective..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                rows={4}
              />
            </div>
            <Button
              onClick={handleSubmitComment}
              disabled={submitting || !authorName.trim() || !comment.trim()}
            >
              {submitting ? (
                <>Submitting...</>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Share Advice
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Previous Comments */}
        {comments.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                Advice from Friends ({comments.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {comments.map((c) => (
                <div key={c.id} className="p-4 rounded-lg bg-secondary/30 border">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                      <User className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{c.author}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(c.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                  <p className="text-foreground/80 whitespace-pre-wrap">{c.content}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Log Similar Decision CTA */}
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="py-6 text-center space-y-4">
            <Sparkles className="w-10 h-10 mx-auto text-primary" />
            <div>
              <h3 className="text-lg font-semibold">Facing a similar decision?</h3>
              <p className="text-muted-foreground text-sm">
                Track your own decisions and build your decision-making wisdom
              </p>
            </div>
            <Button onClick={handleLogSimilar} variant="default">
              Log Similar Decision
            </Button>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default SharedDecision;
