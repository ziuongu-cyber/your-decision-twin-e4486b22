import { useState, useEffect, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Filter,
  X,
  Calendar as CalendarIcon,
  ChevronDown,
  Tag,
  Check,
  ThumbsUp,
  ThumbsDown,
  Clock,
  CheckCircle,
} from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Decision } from "@/lib/storage";
import { DateRange } from "react-day-picker";

const CATEGORIES = [
  "Career",
  "Finance",
  "Health",
  "Relationships",
  "Purchase",
  "Daily Habit",
  "Other",
];

const OUTCOME_FILTERS = [
  { value: "with", label: "With outcomes", icon: CheckCircle },
  { value: "without", label: "Without outcomes", icon: Clock },
  { value: "positive", label: "Positive outcomes", icon: ThumbsUp },
  { value: "negative", label: "Negative outcomes", icon: ThumbsDown },
];

export interface FilterState {
  categories: string[];
  confidenceRange: [number, number];
  outcomeFilters: string[];
  dateRange: DateRange | undefined;
  tags: string[];
}

interface AdvancedFiltersProps {
  decisions: Decision[];
  filters: FilterState;
  onChange: (filters: FilterState) => void;
  onClear: () => void;
}

const AdvancedFilters = ({
  decisions,
  filters,
  onChange,
  onClear,
}: AdvancedFiltersProps) => {
  const [isOpen, setIsOpen] = useState(false);

  // Extract all unique tags from decisions
  const allTags = useMemo(() => {
    const tagSet = new Set<string>();
    decisions.forEach((d) => d.tags.forEach((tag) => tagSet.add(tag)));
    return Array.from(tagSet).sort();
  }, [decisions]);

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (filters.categories.length > 0) count++;
    if (filters.confidenceRange[0] !== 1 || filters.confidenceRange[1] !== 10) count++;
    if (filters.outcomeFilters.length > 0) count++;
    if (filters.dateRange?.from || filters.dateRange?.to) count++;
    if (filters.tags.length > 0) count++;
    return count;
  }, [filters]);

  const toggleCategory = (category: string) => {
    const newCategories = filters.categories.includes(category)
      ? filters.categories.filter((c) => c !== category)
      : [...filters.categories, category];
    onChange({ ...filters, categories: newCategories });
  };

  const toggleOutcomeFilter = (value: string) => {
    const newFilters = filters.outcomeFilters.includes(value)
      ? filters.outcomeFilters.filter((f) => f !== value)
      : [...filters.outcomeFilters, value];
    onChange({ ...filters, outcomeFilters: newFilters });
  };

  const toggleTag = (tag: string) => {
    const newTags = filters.tags.includes(tag)
      ? filters.tags.filter((t) => t !== tag)
      : [...filters.tags, tag];
    onChange({ ...filters, tags: newTags });
  };

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <div className="flex items-center gap-2 mb-4">
        <CollapsibleTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2">
            <Filter className="w-4 h-4" />
            Advanced Filters
            {activeFilterCount > 0 && (
              <Badge variant="secondary" className="ml-1 px-1.5 py-0 text-xs">
                {activeFilterCount}
              </Badge>
            )}
            <ChevronDown
              className={cn(
                "w-4 h-4 transition-transform",
                isOpen && "rotate-180"
              )}
            />
          </Button>
        </CollapsibleTrigger>

        {activeFilterCount > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClear}
            className="gap-1 text-muted-foreground hover:text-foreground"
          >
            <X className="w-3.5 h-3.5" />
            Clear all
          </Button>
        )}
      </div>

      <CollapsibleContent>
        <div className="glass-card rounded-xl p-4 space-y-6 mb-4">
          {/* Categories */}
          <div>
            <label className="text-sm font-medium mb-3 block">Categories</label>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((category) => (
                <button
                  key={category}
                  onClick={() => toggleCategory(category)}
                  className={cn(
                    "px-3 py-1.5 rounded-full text-sm transition-colors border",
                    filters.categories.includes(category)
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-secondary border-border/50 hover:border-primary/50"
                  )}
                >
                  {filters.categories.includes(category) && (
                    <Check className="w-3 h-3 inline mr-1" />
                  )}
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Confidence Range */}
          <div>
            <label className="text-sm font-medium mb-3 block">
              Confidence Range: {filters.confidenceRange[0]} - {filters.confidenceRange[1]}
            </label>
            <div className="px-2">
              <Slider
                min={1}
                max={10}
                step={1}
                value={filters.confidenceRange}
                onValueChange={(value) =>
                  onChange({
                    ...filters,
                    confidenceRange: value as [number, number],
                  })
                }
                className="w-full"
              />
              <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                <span>1</span>
                <span>5</span>
                <span>10</span>
              </div>
            </div>
          </div>

          {/* Outcome Filter */}
          <div>
            <label className="text-sm font-medium mb-3 block">Outcome Status</label>
            <div className="flex flex-wrap gap-2">
              {OUTCOME_FILTERS.map((filter) => {
                const Icon = filter.icon;
                return (
                  <button
                    key={filter.value}
                    onClick={() => toggleOutcomeFilter(filter.value)}
                    className={cn(
                      "flex items-center gap-2 px-3 py-1.5 rounded-full text-sm transition-colors border",
                      filters.outcomeFilters.includes(filter.value)
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-secondary border-border/50 hover:border-primary/50"
                    )}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {filter.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date Range */}
          <div>
            <label className="text-sm font-medium mb-3 block">Date Range</label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !filters.dateRange?.from && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.dateRange?.from ? (
                    filters.dateRange.to ? (
                      <>
                        {format(filters.dateRange.from, "LLL dd, y")} -{" "}
                        {format(filters.dateRange.to, "LLL dd, y")}
                      </>
                    ) : (
                      format(filters.dateRange.from, "LLL dd, y")
                    )
                  ) : (
                    "Pick a date range"
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 bg-popover" align="start">
                <Calendar
                  initialFocus
                  mode="range"
                  defaultMonth={filters.dateRange?.from}
                  selected={filters.dateRange}
                  onSelect={(range) =>
                    onChange({ ...filters, dateRange: range })
                  }
                  numberOfMonths={2}
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Tags */}
          {allTags.length > 0 && (
            <div>
              <label className="text-sm font-medium mb-3 block flex items-center gap-2">
                <Tag className="w-4 h-4" />
                Tags ({allTags.length} available)
              </label>
              <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                {allTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => toggleTag(tag)}
                    className={cn(
                      "px-2.5 py-1 rounded-full text-xs transition-colors border",
                      filters.tags.includes(tag)
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-secondary border-border/50 hover:border-primary/50"
                    )}
                  >
                    #{tag}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
};

export default AdvancedFilters;
