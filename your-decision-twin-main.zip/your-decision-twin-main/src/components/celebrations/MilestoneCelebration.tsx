import { useEffect, useState } from "react";
import confetti from "canvas-confetti";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Trophy, Star, Zap, Crown, Rocket } from "lucide-react";

interface Milestone {
  count: number;
  title: string;
  description: string;
  icon: typeof Trophy;
}

const MILESTONES: Milestone[] = [
  { count: 1, title: "First Step!", icon: Star, description: "You logged your first decision. Your digital twin is born!" },
  { count: 10, title: "Getting Started!", icon: Zap, description: "10 decisions logged. Your twin is learning your patterns." },
  { count: 25, title: "Building Momentum!", icon: Trophy, description: "25 decisions! Your insights are becoming powerful." },
  { count: 50, title: "Decision Master!", icon: Crown, description: "50 decisions! You're a decision-making pro." },
  { count: 100, title: "Century Club!", icon: Rocket, description: "100 decisions! Your twin knows you deeply." },
];

const MILESTONE_STORAGE_KEY = "celebrated_milestones";

async function getCelebratedMilestones(): Promise<number[]> {
  try {
    if (window.storage?.get) {
      const data = await window.storage.get(MILESTONE_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    }
    const data = localStorage.getItem(MILESTONE_STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

async function saveCelebratedMilestone(count: number): Promise<void> {
  const celebrated = await getCelebratedMilestones();
  if (!celebrated.includes(count)) {
    celebrated.push(count);
    const data = JSON.stringify(celebrated);
    if (window.storage?.set) {
      await window.storage.set(MILESTONE_STORAGE_KEY, data);
    } else {
      localStorage.setItem(MILESTONE_STORAGE_KEY, data);
    }
  }
}

interface MilestoneCelebrationProps {
  decisionCount: number;
}

export function MilestoneCelebration({ decisionCount }: MilestoneCelebrationProps) {
  const [showCelebration, setShowCelebration] = useState(false);
  const [currentMilestone, setCurrentMilestone] = useState<Milestone | null>(null);

  useEffect(() => {
    const checkMilestone = async () => {
      const milestone = MILESTONES.find((m) => m.count === decisionCount);
      if (!milestone) return;

      const celebrated = await getCelebratedMilestones();
      if (celebrated.includes(milestone.count)) return;

      setCurrentMilestone(milestone);
      setShowCelebration(true);
      await saveCelebratedMilestone(milestone.count);

      // Fire confetti
      const duration = 3000;
      const end = Date.now() + duration;

      const colors = ["#a855f7", "#8b5cf6", "#6366f1", "#ec4899", "#f97316"];

      (function frame() {
        confetti({
          particleCount: 3,
          angle: 60,
          spread: 55,
          origin: { x: 0, y: 0.7 },
          colors,
        });
        confetti({
          particleCount: 3,
          angle: 120,
          spread: 55,
          origin: { x: 1, y: 0.7 },
          colors,
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      })();
    };

    if (decisionCount > 0) {
      checkMilestone();
    }
  }, [decisionCount]);

  if (!currentMilestone) return null;

  const Icon = currentMilestone.icon;

  return (
    <Dialog open={showCelebration} onOpenChange={setShowCelebration}>
      <DialogContent className="sm:max-w-md text-center">
        <div className="flex flex-col items-center py-6">
          <div className="w-20 h-20 rounded-full gradient-bg flex items-center justify-center mb-4 animate-scale-in">
            <Icon className="w-10 h-10 text-primary-foreground" />
          </div>
          <h2 className="text-2xl font-bold mb-2 gradient-text">
            {currentMilestone.title}
          </h2>
          <p className="text-muted-foreground mb-6">
            {currentMilestone.description}
          </p>
          <Button onClick={() => setShowCelebration(false)} variant="hero">
            Keep Going! 🚀
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
