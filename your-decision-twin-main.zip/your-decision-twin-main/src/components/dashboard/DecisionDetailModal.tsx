import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Decision, getAllDecisions } from "@/lib/storage";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { format, formatDistanceToNow, differenceInHours } from "date-fns";
import {
  Briefcase,
  DollarSign,
  Heart,
  Users,
  ShoppingCart,
  RefreshCw,
  HelpCircle,
  Plus,
  Trash2,
  Calendar,
  MessageSquare,
  Edit,
  ChevronDown,
  Sparkles,
  X,
  CheckCircle,
  Clock,
  Tag,
  ListChecks,
  FileText,
  Share2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import ShareDecisionModal from "@/components/sharing/ShareDecisionModal";

interface DecisionDetailModalProps {
  decision: Decision | null;
  open: boolean;
  onClose: () => void;
  onAddOutcome?: (decisionId: string) => void;
  onDelete?: (decisionId: string) => void;
}

const CATEGORY_CONFIG: Record<
  string,
  { icon: React.ElementType; color: string; bgColor: string }
> = {
  Career: { icon: Briefcase, color: "text-blue-400", bgColor: "bg-blue-500/20" },
  Finance: { icon: DollarSign, color: "text-green-400", bgColor: "bg-green-500/20" },
  Health: { icon: Heart, color: "text-red-400", bgColor: "bg-red-500/20" },
  Relationships: { icon: Users, color: "text-pink-400", bgColor: "bg-pink-500/20" },
  Purchase: { icon: ShoppingCart, color: "text-yellow-400", bgColor: "bg-yellow-500/20" },
  "Daily Habit": { icon: RefreshCw, color: "text-cyan-400", bgColor: "bg-cyan-500/20" },
  Other: { icon: HelpCircle, color: "text-gray-400", bgColor: "bg-gray-500/20" },
};

const getConfidenceColor = (confidence: number) => {
  if (confidence <= 3) return "bg-red-500";
  if (confidence <= 5) return "bg-yellow-500";
  if (confidence <= 7) return "bg-blue-500";
  return "bg-green-500";
};

const getConfidenceLabel = (confidence: number) => {
  if (confidence <= 3) return "Low";
  if (confidence <= 5) return "Moderate";
  if (confidence <= 7) return "High";
  return "Very High";
};

const getOutcomeColor = (rating: number) => {
  if (rating < 4) return "text-red-400 bg-red-500/20 border-red-500/30";
  if (rating <= 7) return "text-yellow-400 bg-yellow-500/20 border-yellow-500/30";
  return "text-green-400 bg-green-500/20 border-green-500/30";
};

const DecisionDetailModal = ({
  decision,
  open,
  onClose,
  onAddOutcome,
  onDelete,
}: DecisionDetailModalProps) => {
  const navigate = useNavigate();
  const [contextExpanded, setContextExpanded] = useState(false);
  const [similarDecisions, setSimilarDecisions] = useState<Decision[]>([]);
  const [loadingSimilar, setLoadingSimilar] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);

  useEffect(() => {
    if (decision && open) {
      loadSimilarDecisions();
    }
  }, [decision, open]);

  const loadSimilarDecisions = async () => {
    if (!decision) return;
    setLoadingSimilar(true);
    try {
      const allDecisions = await getAllDecisions();
      // Find similar decisions based on category and tags
      const similar = allDecisions
        .filter(d => d.id !== decision.id)
        .map(d => {
          let score = 0;
          if (d.category === decision.category) score += 3;
          const sharedTags = d.tags.filter(t => decision.tags.includes(t));
          score += sharedTags.length * 2;
          // Boost if similar confidence level
          if (Math.abs(d.confidence - decision.confidence) <= 2) score += 1;
          return { decision: d, score };
        })
        .filter(item => item.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 3)
        .map(item => item.decision);
      setSimilarDecisions(similar);
    } catch (error) {
      console.error("Failed to load similar decisions:", error);
    } finally {
      setLoadingSimilar(false);
    }
  };

  if (!decision) return null;

  const categoryConfig = CATEGORY_CONFIG[decision.category] || CATEGORY_CONFIG.Other;
  const CategoryIcon = categoryConfig.icon;
  const hasOutcomes = decision.outcomes && decision.outcomes.length > 0;
  const hoursSinceCreated = differenceInHours(new Date(), new Date(decision.createdAt));
  const canAddOutcome = hoursSinceCreated >= 24;

  // Check if there's a recent outcome (within last 7 days)
  const recentOutcome = hasOutcomes 
    ? decision.outcomes.find(o => differenceInHours(new Date(), new Date(o.createdAt)) < 24 * 7)
    : null;

  const handleAskTwin = () => {
    const context = `I made this decision: "${decision.title}". I chose "${decision.choice}". ${
      decision.context ? `My thinking was: ${decision.context}` : ""
    } What do you think about this decision based on my patterns?`;
    
    navigate("/ask-twin", { state: { prefillQuestion: context } });
    onClose();
  };

  const handleEditClick = () => {
    navigate("/log-decision", { state: { editDecision: decision } });
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[95vh] md:max-h-[90vh] overflow-hidden p-0 gap-0 max-sm:h-[100dvh] max-sm:max-h-[100dvh] max-sm:rounded-none">
        {/* Header */}
        <div className="relative border-b border-border p-4 md:p-6">
          <div className="flex items-start gap-4">
            <div
              className={cn(
                "w-12 h-12 rounded-xl flex items-center justify-center shrink-0",
                categoryConfig.bgColor
              )}
            >
              <CategoryIcon className={cn("w-6 h-6", categoryConfig.color)} />
            </div>
            <div className="flex-1 min-w-0 pr-8">
              <div className="flex items-center gap-2 mb-2">
                <Badge
                  variant="secondary"
                  className={cn("text-xs", categoryConfig.bgColor, categoryConfig.color)}
                >
                  {decision.category}
                </Badge>
              </div>
              <DialogTitle className="text-xl md:text-2xl font-bold leading-tight">
                {decision.title}
              </DialogTitle>
            </div>
          </div>
          
          {/* Metadata row */}
          <div className="flex flex-wrap items-center gap-3 mt-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4" />
              {format(new Date(decision.createdAt), "MMM d, yyyy")}
            </div>
            <div className="flex items-center gap-2">
              <div className={cn("w-2 h-2 rounded-full", getConfidenceColor(decision.confidence))} />
              <span>{getConfidenceLabel(decision.confidence)} confidence ({decision.confidence}/10)</span>
            </div>
            {decision.tags.length > 0 && (
              <div className="flex items-center gap-1.5">
                <Tag className="w-4 h-4" />
                <span>{decision.tags.length} tags</span>
              </div>
            )}
          </div>
        </div>

        {/* Scrollable content */}
        <div className="overflow-y-auto max-h-[60vh] md:max-h-[55vh] p-4 md:p-6 space-y-6">
          {/* Your Choice - highlighted card */}
          <section>
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-primary" />
              Your Choice
            </h3>
            <div className="bg-primary/10 border border-primary/20 rounded-xl p-4">
              <p className="text-lg font-medium">{decision.choice}</p>
            </div>
          </section>

          {/* Alternatives Considered */}
          {decision.alternatives.length > 0 && (
            <section>
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                <ListChecks className="w-4 h-4" />
                Alternatives Considered
              </h3>
              <ul className="space-y-2">
                {decision.alternatives.map((alt, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-3 text-foreground/80"
                  >
                    <span className="w-5 h-5 rounded-full bg-secondary flex items-center justify-center text-xs text-muted-foreground shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span>{alt}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Your Thinking - expandable */}
          {decision.context && (
            <section>
              <Collapsible open={contextExpanded} onOpenChange={setContextExpanded}>
                <CollapsibleTrigger asChild>
                  <button className="w-full text-left">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      Your Thinking
                      <ChevronDown className={cn(
                        "w-4 h-4 transition-transform ml-auto",
                        contextExpanded && "rotate-180"
                      )} />
                    </h3>
                  </button>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="bg-secondary/50 rounded-xl p-4 text-foreground/80 whitespace-pre-wrap">
                    {decision.context}
                  </div>
                </CollapsibleContent>
                {!contextExpanded && (
                  <p className="text-sm text-muted-foreground italic line-clamp-2">
                    {decision.context.slice(0, 150)}
                    {decision.context.length > 150 ? "..." : ""}
                  </p>
                )}
              </Collapsible>
            </section>
          )}

          {/* Tags */}
          {decision.tags.length > 0 && (
            <section>
              <div className="flex flex-wrap gap-2">
                {decision.tags.map((tag) => (
                  <Badge key={tag} variant="outline" className="text-xs">
                    #{tag}
                  </Badge>
                ))}
              </div>
            </section>
          )}

          {/* Outcomes Timeline */}
          {hasOutcomes && (
            <section>
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Outcomes Timeline ({decision.outcomes.length})
              </h3>
              <div className="relative pl-6 border-l-2 border-border space-y-4">
                {decision.outcomes
                  .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
                  .map((outcome, idx) => (
                    <div key={outcome.id} className="relative">
                      <div className={cn(
                        "absolute -left-[1.65rem] w-4 h-4 rounded-full border-2",
                        getOutcomeColor(outcome.rating)
                      )} />
                      <div className={cn(
                        "rounded-xl p-4 border",
                        getOutcomeColor(outcome.rating)
                      )}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-bold text-lg">{outcome.rating}/10</span>
                          <span className="text-xs text-muted-foreground">
                            {formatDistanceToNow(new Date(outcome.createdAt), { addSuffix: true })}
                          </span>
                        </div>
                        {outcome.wouldChooseDifferently && (
                          <Badge variant="outline" className="text-xs mb-2">
                            Would choose differently
                          </Badge>
                        )}
                        {outcome.reflection && (
                          <p className="text-sm italic">"{outcome.reflection}"</p>
                        )}
                      </div>
                    </div>
                  ))}
              </div>
            </section>
          )}

          {/* Similar Decisions */}
          {similarDecisions.length > 0 && (
            <section>
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-primary" />
                Similar Decisions
              </h3>
              <div className="space-y-2">
                {similarDecisions.map((sim) => {
                  const simConfig = CATEGORY_CONFIG[sim.category] || CATEGORY_CONFIG.Other;
                  const SimIcon = simConfig.icon;
                  return (
                    <div
                      key={sim.id}
                      className="flex items-center gap-3 p-3 rounded-lg border bg-secondary/30 hover:bg-secondary/50 transition-colors"
                    >
                      <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", simConfig.bgColor)}>
                        <SimIcon className={cn("w-4 h-4", simConfig.color)} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{sim.title}</p>
                        <p className="text-xs text-muted-foreground truncate">{sim.choice}</p>
                      </div>
                      <span className="text-xs text-muted-foreground whitespace-nowrap">
                        {formatDistanceToNow(new Date(sim.createdAt), { addSuffix: true })}
                      </span>
                    </div>
                  );
                })}
              </div>
            </section>
          )}
        </div>

        {/* Action buttons - sticky footer */}
        <div className="border-t border-border p-4 md:p-6 bg-background/95 backdrop-blur-sm">
          <div className="flex flex-wrap gap-2">
            {!recentOutcome && canAddOutcome && onAddOutcome && (
              <Button 
                variant="default"
                className="flex-1 sm:flex-none"
                onClick={() => {
                  onAddOutcome(decision.id);
                  onClose();
                }}
              >
                <Plus className="w-4 h-4" />
                Add Outcome
              </Button>
            )}
            
            <Button 
              variant="outline"
              className="flex-1 sm:flex-none"
              onClick={() => setShareModalOpen(true)}
            >
              <Share2 className="w-4 h-4" />
              Share with Friend
            </Button>
            
            <Button 
              variant="ghost"
              className="flex-1 sm:flex-none"
              onClick={handleAskTwin}
            >
              <MessageSquare className="w-4 h-4" />
              Ask Twin
            </Button>

            <Button 
              variant="ghost"
              size="icon"
              onClick={handleEditClick}
            >
              <Edit className="w-4 h-4" />
            </Button>

            {onDelete && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently delete "{decision.title}" and all its outcomes. This cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => {
                        onDelete(decision.id);
                        onClose();
                      }}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      Delete Forever
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>
        </div>

        {/* Share Modal */}
        <ShareDecisionModal
          decision={decision}
          open={shareModalOpen}
          onClose={() => setShareModalOpen(false)}
        />
      </DialogContent>
    </Dialog>
  );
};

export default DecisionDetailModal;
